#!/usr/bin/env python3
"""Standard inference entrypoint with generated-image support."""

import os
import json
import argparse
import traceback
import time
from contextlib import contextmanager
from collections import Counter
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union
import torch
import numpy as np
from PIL import Image
from tqdm.auto import tqdm

from . import base
from bon_utils import AnswerSpan, SegmentTextInfo, extract_answers_and_signature
from data.data_utils import pil_img2rgb
from online_gate import OnlineGateAbortImageGeneration, get_online_gate_controller
from runtime_metrics import get_metric_dumper

try:
    from torch.cuda import nvtx
except Exception:
    nvtx = None


@contextmanager
def nvtx_range(message: str):
    if nvtx is None:
        yield
        return
    nvtx.range_push(message)
    try:
        yield
    finally:
        nvtx.range_pop()


@dataclass
class ReasoningCandidate:
    index: int
    reasoning_steps: List[Dict[str, Any]]
    prediction_solution: str
    answers: List[Optional[str]]
    signature: Tuple[Optional[str], ...]
    reasoning_logprob: float
    reasoning_token_count: int
    reasoning_mean_logprob: float
    answer_logprob: float
    trial_seed: Optional[int] = None
    output_subdir: Optional[str] = None
    answer_spans: Optional[List[Optional[AnswerSpan]]] = None
    profiling_log: Optional[List[Dict[str, Any]]] = None


class BestOfNReasoner(base.InterleaveReasoner):
    def __init__(self, inferencer):
        super().__init__(inferencer)
        self.metric_dumper = get_metric_dumper()
        self._generated_image_swap_cache = None

    @staticmethod
    def _generated_image_intervention_mode() -> str:
        return (
            str(os.environ.get("BAGEL_GENERATED_IMAGE_INTERVENTION", "") or "")
            .strip()
            .lower()
        )

    @staticmethod
    def _generated_image_intervention_trial_filter() -> Optional[set[int]]:
        raw = str(
            os.environ.get("BAGEL_GENERATED_IMAGE_INTERVENTION_TRIALS", "") or ""
        ).strip()
        if not raw:
            return None
        out = set()
        for tok in raw.split(","):
            tok = tok.strip()
            if not tok:
                continue
            try:
                out.add(int(tok))
            except ValueError:
                continue
        return out or None

    def _load_generated_image_swap_map(self):
        if self._generated_image_swap_cache is not None:
            return self._generated_image_swap_cache
        path = str(os.environ.get("BAGEL_GENERATED_IMAGE_SWAP_JSON", "") or "").strip()
        if not path:
            self._generated_image_swap_cache = {}
            return self._generated_image_swap_cache
        try:
            with open(path) as f:
                self._generated_image_swap_cache = json.load(f)
        except Exception:
            self._generated_image_swap_cache = {}
        return self._generated_image_swap_cache

    def _apply_generated_image_intervention(
        self,
        image: Image.Image,
        *,
        sample_id: Optional[str],
        trial_id: Optional[int],
    ) -> tuple[Optional[Image.Image], str]:
        mode = self._generated_image_intervention_mode()
        if not mode:
            return image, "original"
        allowed_trials = self._generated_image_intervention_trial_filter()
        if allowed_trials is not None and trial_id not in allowed_trials:
            return image, "original"

        if mode == "skip":
            return None, "skip"
        if mode == "zero":
            return Image.new("RGB", image.size, (0, 0, 0)), "zero"
        if mode == "noise":
            seed = int(os.environ.get("BAGEL_GENERATED_IMAGE_NOISE_SEED", "1234"))
            rng = np.random.default_rng(seed + int(trial_id or 0))
            arr = rng.integers(
                0, 256, size=(image.size[1], image.size[0], 3), dtype=np.uint8
            )
            return Image.fromarray(arr, mode="RGB"), "noise"
        if mode == "swap":
            swap_map = self._load_generated_image_swap_map()
            sample_key = str(sample_id) if sample_id is not None else ""
            trial_key = str(trial_id) if trial_id is not None else ""
            src = (
                swap_map.get(sample_key, {}).get(trial_key)
                or swap_map.get(trial_key)
                or swap_map.get(f"{sample_key}:{trial_key}")
            )
            if src:
                try:
                    return pil_img2rgb(Image.open(src)), "swap"
                except Exception:
                    pass
        return image, "original"

    def _set_trace(
        self,
        gen_context: Dict[str, Any],
        *,
        sample_id: Optional[str],
        trial_id: Optional[int],
        iteration: Any,
        stage: str,
        context_label: Optional[str] = None,
        label: Optional[str] = None,
        query_kind: Optional[str] = None,
        extra_trace_fields: Optional[Dict[str, Any]] = None,
    ):
        trace_fields = dict(extra_trace_fields or {})
        trace_fields.update(
            {
                "sample_id": str(sample_id) if sample_id is not None else None,
                "trial_id": trial_id,
                "iteration": iteration,
                "stage": stage,
                "context": context_label,
                "label": label,
                "query_kind": query_kind,
            }
        )
        self.inferencer.update_trace(
            gen_context,
            **trace_fields,
        )

    def _generate_text_segment(
        self, gen_context, inference_kwargs
    ) -> Tuple[SegmentTextInfo, str, Dict[str, float]]:
        start = time.perf_counter()
        trace = dict(gen_context.get("trace", {}))
        dump_decode_jsonl = self.metric_dumper.should_write_jsonl(
            trace.get("sample_id")
        )
        # Keep decode_topk for all cases where JSONL metrics are enabled, while
        # heavier attention tensors remain gated by trial-selected full dumps.
        dump_decode_topk_tensor = dump_decode_jsonl
        if dump_decode_topk_tensor:
            (
                ids,
                token_logprobs,
                token_top2_probs,
                token_topk_truncated_entropy,
                token_top10_probs,
                token_top10_ids,
            ) = self.inferencer.gen_text(
                gen_context,
                do_sample=inference_kwargs.get("do_sample", True),
                temperature=inference_kwargs.get("text_temperature", 0.3),
                return_ids=True,
                return_logprobs=True,
                return_top2_probs=True,
                return_topk_truncated_entropy=True,
                return_topk_probs=True,
                return_topk_ids=True,
                topk_truncated_entropy_k=10,
            )
        else:
            ids, token_logprobs, token_top2_probs = self.inferencer.gen_text(
                gen_context,
                do_sample=inference_kwargs.get("do_sample", True),
                temperature=inference_kwargs.get("text_temperature", 0.3),
                return_ids=True,
                return_logprobs=True,
                return_top2_probs=True,
            )
            token_topk_truncated_entropy = torch.empty((0,), dtype=torch.float32)
            token_top10_probs = torch.empty((0, 10), dtype=torch.float32)
            token_top10_ids = torch.empty((0, 10), dtype=torch.long)
        decode_ms = (time.perf_counter() - start) * 1000.0
        # print(repr(token_logprobs))
        next_action_token = ids[-1]
        text_token_ids = ids[1:-2]
        token_id_list = (
            text_token_ids.tolist()
            if hasattr(text_token_ids, "tolist")
            else list(text_token_ids)
        )
        token_texts = [
            self.tokenizer.decode([tok_id], skip_special_tokens=False)
            for tok_id in token_id_list
        ]
        raw_text = "".join(token_texts)
        decoded_text = raw_text.strip()
        next_action = self.action_token_map.get(next_action_token, "undefined")
        if token_logprobs.numel() > 0:
            text_span = token_logprobs[1:-2]
            token_nan_mask = torch.isnan(text_span).detach().cpu().tolist()
            token_logprob_values = (
                torch.nan_to_num(text_span, nan=0.0).detach().float().cpu().tolist()
            )
        else:
            token_logprob_values = []
            token_nan_mask = []
        if token_top2_probs.numel() > 0:
            token_top2_values = token_top2_probs[1:-2].detach().float().cpu()
        else:
            token_top2_values = torch.empty((0, 2), dtype=torch.float32)
        if token_topk_truncated_entropy.numel() > 0:
            token_topk_entropy_values = (
                token_topk_truncated_entropy[1:-2].detach().float().cpu()
            )
        else:
            token_topk_entropy_values = torch.empty((0,), dtype=torch.float32)
        if token_top10_probs.numel() > 0:
            token_top10_prob_values = token_top10_probs[1:-2].detach().float().cpu()
        else:
            token_top10_prob_values = torch.empty((0, 10), dtype=torch.float32)
        if token_top10_ids.numel() > 0:
            token_top10_id_values = token_top10_ids[1:-2].detach().long().cpu()
        else:
            token_top10_id_values = torch.empty((0, 10), dtype=torch.long)

        if dump_decode_topk_tensor and token_top10_prob_values.numel() > 0:
            self.metric_dumper.save_tensor(
                "decode_topk",
                trace,
                {
                    "top10_probs": token_top10_prob_values,
                    "top10_ids": token_top10_id_values,
                    "token_topk_truncated_entropy": token_topk_entropy_values,
                    "token_ids": torch.tensor(token_id_list, dtype=torch.long),
                    "token_texts": token_texts,
                },
            )
        uncertainty_value = None
        if token_top2_values.numel() > 0:
            top2_values = torch.nan_to_num(token_top2_values, nan=0.0)
            top2_margin = top2_values[:, 0] - top2_values[:, 1]
            uncertainty = 1.0 - top2_margin.mean()
            uncertainty_value = float(uncertainty.item())
        if dump_decode_jsonl and uncertainty_value is not None:
            self.metric_dumper.write_jsonl(
                "decode_top2_summary",
                trace,
                {
                    "uncertainty": uncertainty_value,
                },
            )
        if dump_decode_jsonl and token_topk_entropy_values.numel() > 0:
            self.metric_dumper.write_jsonl(
                "decode_topk_summary",
                trace,
                {
                    "truncated_entropy": float(token_topk_entropy_values.mean().item()),
                },
            )

        segment_info = SegmentTextInfo(
            text=decoded_text,
            raw_text=raw_text,
            token_texts=token_texts,
            token_logprobs=token_logprob_values,
            token_logprob_nan_mask=token_nan_mask,
        )
        stats = {
            "elapsed_ms": decode_ms,
            "text_tokens": max(len(text_token_ids), 0),
            "total_tokens": len(ids),
        }
        if uncertainty_value is not None:
            stats["uncertainty"] = uncertainty_value
        return segment_info, next_action, stats

    def _run_single_trace(
        self,
        inputs: List[Union[str, Image.Image]],
        system_prompt: Optional[str],
        max_iterations: int,
        verbose_iter: bool,
        verbose_image: bool,
        inference_kwargs: Dict[str, Any],
        sample_id: Optional[str],
        trial_id: Optional[int],
    ) -> Tuple[List[Dict[str, Any]], str, List[SegmentTextInfo], List[Dict[str, Any]]]:
        reasoning_steps: List[Dict[str, Any]] = []
        collected_texts: List[str] = []
        segment_infos: List[SegmentTextInfo] = []
        profiling_events: List[Dict[str, Any]] = []

        gen_context = self.inferencer.init_gen_context()
        cfg_text_context = self.inferencer.init_gen_context()
        cfg_img_context = self.inferencer.init_gen_context()
        gate = get_online_gate_controller()
        force_wo_after_gate = False

        image_shapes = (512, 512)
        with torch.autocast(device_type="cuda", enabled=True, dtype=torch.bfloat16):
            if system_prompt:
                prompt_text = system_prompt.strip()
                if prompt_text:
                    token_count = self._count_text_tokens(prompt_text)
                    self._set_trace(
                        gen_context,
                        sample_id=sample_id,
                        trial_id=trial_id,
                        iteration="pre",
                        stage="text_prefill",
                        context_label="gen",
                        label="system_prompt",
                        query_kind="text",
                    )
                    with nvtx_range("text_prefill:system_prompt:gen"):
                        gen_context = self._profile_call(
                            profiling_events,
                            "text_prefill",
                            self.inferencer.update_context_text,
                            prompt_text,
                            gen_context,
                            segment_meta={
                                "context": "gen",
                                "label": "system_prompt",
                                "iteration": "pre",
                                "source": "system_prompt",
                            },
                            **self._text_prefill_meta(
                                "gen", "system_prompt", "pre", token_count
                            ),
                        )
                    self._set_trace(
                        cfg_img_context,
                        sample_id=sample_id,
                        trial_id=trial_id,
                        iteration="pre",
                        stage="text_prefill",
                        context_label="cfg_img",
                        label="system_prompt",
                        query_kind="text",
                    )
                    with nvtx_range("text_prefill:system_prompt:cfg_img"):
                        cfg_img_context = self._profile_call(
                            profiling_events,
                            "text_prefill",
                            self.inferencer.update_context_text,
                            prompt_text,
                            cfg_img_context,
                            segment_meta={
                                "context": "cfg_img",
                                "label": "system_prompt",
                                "iteration": "pre",
                                "source": "system_prompt",
                            },
                            **self._text_prefill_meta(
                                "cfg_img", "system_prompt", "pre", token_count
                            ),
                        )

            for input_item in inputs:
                if isinstance(input_item, str):
                    content = input_item.strip()
                    if content:
                        token_count = self._count_text_tokens(content)
                        self._set_trace(
                            gen_context,
                            sample_id=sample_id,
                            trial_id=trial_id,
                            iteration="pre",
                            stage="text_prefill",
                            context_label="gen",
                            label="input_text",
                            query_kind="text",
                        )
                        with nvtx_range("text_prefill:input_text:gen"):
                            gen_context = self._profile_call(
                                profiling_events,
                                "text_prefill",
                                self.inferencer.update_context_text,
                                content,
                                gen_context,
                                segment_meta={
                                    "context": "gen",
                                    "label": "input_text",
                                    "iteration": "pre",
                                    "source": "input_text",
                                },
                                **self._text_prefill_meta(
                                    "gen", "input_text", "pre", token_count
                                ),
                            )
                        self._set_trace(
                            cfg_img_context,
                            sample_id=sample_id,
                            trial_id=trial_id,
                            iteration="pre",
                            stage="text_prefill",
                            context_label="cfg_img",
                            label="input_text",
                            query_kind="text",
                        )
                        with nvtx_range("text_prefill:input_text:cfg_img"):
                            cfg_img_context = self._profile_call(
                                profiling_events,
                                "text_prefill",
                                self.inferencer.update_context_text,
                                content,
                                cfg_img_context,
                                segment_meta={
                                    "context": "cfg_img",
                                    "label": "input_text",
                                    "iteration": "pre",
                                    "source": "input_text",
                                },
                                **self._text_prefill_meta(
                                    "cfg_img", "input_text", "pre", token_count
                                ),
                            )
                elif isinstance(input_item, Image.Image):
                    processed_image = self.inferencer.vae_transform.resize_transform(
                        pil_img2rgb(input_item)
                    )
                    image_shapes = processed_image.size[::-1]
                    prev_tokens_gen = self._kv_length(gen_context)
                    self._set_trace(
                        gen_context,
                        sample_id=sample_id,
                        trial_id=trial_id,
                        iteration="pre",
                        stage="visual_prefill",
                        context_label="gen",
                        label="input_image",
                        query_kind="image",
                    )
                    with nvtx_range("visual_prefill:input_image:gen"):
                        gen_context = self._profile_call(
                            profiling_events,
                            "visual_prefill",
                            self.inferencer.update_context_image,
                            processed_image,
                            gen_context,
                            segment_meta={
                                "context": "gen",
                                "label": "input_image",
                                "iteration": "pre",
                                "source": "input_image",
                            },
                            **self._visual_prefill_meta(
                                "gen", "input_image", "pre", prev_tokens_gen
                            ),
                            vae=True,
                            vit=True,
                        )
                    prev_tokens_cfg = self._kv_length(cfg_text_context)
                    self._set_trace(
                        cfg_text_context,
                        sample_id=sample_id,
                        trial_id=trial_id,
                        iteration="pre",
                        stage="visual_prefill",
                        context_label="cfg_text",
                        label="input_image",
                        query_kind="image",
                    )
                    with nvtx_range("visual_prefill:input_image:cfg_text"):
                        cfg_text_context = self._profile_call(
                            profiling_events,
                            "visual_prefill",
                            self.inferencer.update_context_image,
                            processed_image,
                            cfg_text_context,
                            segment_meta={
                                "context": "cfg_text",
                                "label": "input_image",
                                "iteration": "pre",
                                "source": "input_image",
                            },
                            **self._visual_prefill_meta(
                                "cfg_text", "input_image", "pre", prev_tokens_cfg
                            ),
                            vae=True,
                            vit=True,
                        )
                else:
                    raise ValueError(f"Unsupported input type: {type(input_item)}")

            current_mode = "text"
            with tqdm(
                total=max_iterations,
                desc="Reasoning Steps",
                leave=False,
                disable=(base.d_rank() != 0 or not verbose_iter),
            ) as pbar:
                for iteration in range(max_iterations):
                    if current_mode == "text":
                        pbar.set_description(
                            f"Step {iteration + 1}/{max_iterations}: Generating text"
                        )
                        self._set_trace(
                            gen_context,
                            sample_id=sample_id,
                            trial_id=trial_id,
                            iteration=iteration + 1,
                            stage="text_decode",
                            context_label="gen",
                            label="decode",
                            query_kind="text",
                            extra_trace_fields={
                                "has_generated_image_context": any(
                                    step["type"] == "image" for step in reasoning_steps
                                )
                            },
                        )
                        with nvtx_range("text_decode"):
                            segment_info, next_action, decode_stats = (
                                self._generate_text_segment(
                                    gen_context, inference_kwargs
                                )
                            )
                        decode_event = {
                            "stage": "text_decode",
                            "iteration": iteration + 1,
                            "sample_id": str(sample_id)
                            if sample_id is not None
                            else None,
                            "trial_id": trial_id,
                            **decode_stats,
                        }
                        profiling_events.append(decode_event)
                        if self.metric_dumper.should_write_jsonl(sample_id):
                            self.metric_dumper.write_jsonl(
                                "step_trace",
                                {
                                    "sample_id": str(sample_id),
                                    "trial_id": trial_id,
                                    "iteration": iteration + 1,
                                    "stage": "text_decode",
                                },
                                {
                                    "next_action": next_action,
                                    "text_tokens": decode_stats.get("text_tokens"),
                                    "total_tokens": decode_stats.get("total_tokens"),
                                    "elapsed_ms": decode_stats.get("elapsed_ms"),
                                },
                            )
                        decoded_text = segment_info.text
                        collected_texts.append(decoded_text)
                        segment_infos.append(segment_info)

                        text_token_count = self._count_text_tokens(decoded_text)
                        self._set_trace(
                            gen_context,
                            sample_id=sample_id,
                            trial_id=trial_id,
                            iteration=iteration + 1,
                            stage="text_prefill",
                            context_label="gen",
                            label="generated_text",
                            query_kind="text",
                        )
                        with nvtx_range("text_prefill:generated_text:gen"):
                            gen_context = self._profile_call(
                                profiling_events,
                                "text_prefill",
                                self.inferencer.update_context_text,
                                decoded_text,
                                gen_context,
                                segment_meta={
                                    "context": "gen",
                                    "label": "generated_text",
                                    "iteration": iteration + 1,
                                    "source": "generated_text",
                                },
                                **self._text_prefill_meta(
                                    "gen",
                                    "generated_text",
                                    iteration + 1,
                                    text_token_count,
                                ),
                            )
                        self._set_trace(
                            cfg_img_context,
                            sample_id=sample_id,
                            trial_id=trial_id,
                            iteration=iteration + 1,
                            stage="text_prefill",
                            context_label="cfg_img",
                            label="generated_text",
                            query_kind="text",
                        )
                        with nvtx_range("text_prefill:generated_text:cfg_img"):
                            cfg_img_context = self._profile_call(
                                profiling_events,
                                "text_prefill",
                                self.inferencer.update_context_text,
                                decoded_text,
                                cfg_img_context,
                                segment_meta={
                                    "context": "cfg_img",
                                    "label": "generated_text",
                                    "iteration": iteration + 1,
                                    "source": "generated_text",
                                },
                                **self._text_prefill_meta(
                                    "cfg_img",
                                    "generated_text",
                                    iteration + 1,
                                    text_token_count,
                                ),
                            )

                        reasoning_steps.append(
                            {
                                "type": "text",
                                "content": decoded_text,
                                "iteration": iteration + 1,
                            }
                        )

                        if next_action == "end":
                            pbar.update(1)
                            break
                        else:
                            current_mode = (
                                "image"
                                if (next_action == "image" and not force_wo_after_gate)
                                else "text"
                            )

                    elif current_mode == "image":
                        pbar.set_description(
                            f"Step {iteration + 1}/{max_iterations}: Generating image"
                        )
                        try:
                            gen_image_kwargs = {
                                k: v
                                for k, v in inference_kwargs.items()
                                if k.startswith("cfg_")
                                or k
                                in [
                                    "timestep_shift",
                                    "num_timesteps",
                                    "enable_taylorseer",
                                ]
                            }
                            early_stop_raw = str(
                                os.environ.get(
                                    "BAGEL_IMAGEGEN_EARLY_STOP_SAMPLED_STEPS", ""
                                )
                                or ""
                            ).strip()
                            if early_stop_raw:
                                try:
                                    gen_image_kwargs["early_stop_sampled_steps"] = int(
                                        early_stop_raw
                                    )
                                except ValueError:
                                    pass
                            self._set_trace(
                                gen_context,
                                sample_id=sample_id,
                                trial_id=trial_id,
                                iteration=iteration + 1,
                                stage="image_generation",
                                context_label="gen",
                                label="generated_image",
                                query_kind="vae",
                            )
                            self._set_trace(
                                cfg_text_context,
                                sample_id=sample_id,
                                trial_id=trial_id,
                                iteration=iteration + 1,
                                stage="image_generation",
                                context_label="cfg_text",
                                label="generated_image",
                                query_kind="vae",
                            )
                            self._set_trace(
                                cfg_img_context,
                                sample_id=sample_id,
                                trial_id=trial_id,
                                iteration=iteration + 1,
                                stage="image_generation",
                                context_label="cfg_img",
                                label="generated_image",
                                query_kind="vae",
                            )
                            image_start = time.perf_counter()
                            with nvtx_range("image_generation"):
                                generated_image = self.inferencer.gen_image(
                                    image_shapes,
                                    gen_context,
                                    cfg_text_precontext=cfg_text_context,
                                    cfg_img_precontext=cfg_img_context,
                                    verbose=(verbose_image and base.d_rank() == 0),
                                    **gen_image_kwargs,
                                )
                            image_elapsed_ms = (
                                time.perf_counter() - image_start
                            ) * 1000.0
                            image_event = {
                                "stage": "image_generation",
                                "iteration": iteration + 1,
                                "sample_id": str(sample_id)
                                if sample_id is not None
                                else None,
                                "trial_id": trial_id,
                                "elapsed_ms": image_elapsed_ms,
                            }
                            profiling_events.append(image_event)
                            if self.metric_dumper.should_write_jsonl(sample_id):
                                self.metric_dumper.write_jsonl(
                                    "step_trace",
                                    {
                                        "sample_id": str(sample_id),
                                        "trial_id": trial_id,
                                        "iteration": iteration + 1,
                                        "stage": "image_generation",
                                    },
                                    {"elapsed_ms": image_elapsed_ms},
                                )
                            reasoning_steps.append(
                                {
                                    "type": "image",
                                    "content": generated_image,
                                    "iteration": iteration + 1,
                                }
                            )
                            context_image, intervention_label = (
                                self._apply_generated_image_intervention(
                                    pil_img2rgb(generated_image),
                                    sample_id=sample_id,
                                    trial_id=trial_id,
                                )
                            )
                            image_event["context_intervention"] = intervention_label
                            if context_image is not None:
                                processed_image = (
                                    self.inferencer.vae_transform.resize_transform(
                                        context_image
                                    )
                                )
                                prev_tokens_gen = self._kv_length(gen_context)
                                self._set_trace(
                                    gen_context,
                                    sample_id=sample_id,
                                    trial_id=trial_id,
                                    iteration=iteration + 1,
                                    stage="visual_prefill",
                                    context_label="gen",
                                    label="generated_image",
                                    query_kind="image",
                                )
                                with nvtx_range("visual_prefill:generated_image:gen"):
                                    gen_context = self._profile_call(
                                        profiling_events,
                                        "visual_prefill",
                                        self.inferencer.update_context_image,
                                        processed_image,
                                        gen_context,
                                        segment_meta={
                                            "context": "gen",
                                            "label": "generated_image",
                                            "iteration": iteration + 1,
                                            "source": "generated_image",
                                        },
                                        **self._visual_prefill_meta(
                                            "gen",
                                            "generated_image",
                                            iteration + 1,
                                            prev_tokens_gen,
                                        ),
                                        vae=True,
                                        vit=True,
                                    )
                                prev_tokens_cfg = self._kv_length(cfg_text_context)
                                self._set_trace(
                                    cfg_text_context,
                                    sample_id=sample_id,
                                    trial_id=trial_id,
                                    iteration=iteration + 1,
                                    stage="visual_prefill",
                                    context_label="cfg_text",
                                    label="generated_image",
                                    query_kind="image",
                                )
                                with nvtx_range(
                                    "visual_prefill:generated_image:cfg_text"
                                ):
                                    cfg_text_context = self._profile_call(
                                        profiling_events,
                                        "visual_prefill",
                                        self.inferencer.update_context_image,
                                        processed_image,
                                        cfg_text_context,
                                        segment_meta={
                                            "context": "cfg_text",
                                            "label": "generated_image",
                                            "iteration": iteration + 1,
                                            "source": "generated_image",
                                        },
                                        **self._visual_prefill_meta(
                                            "cfg_text",
                                            "generated_image",
                                            iteration + 1,
                                            prev_tokens_cfg,
                                        ),
                                        vae=True,
                                        vit=True,
                                    )
                            current_mode = "text"
                        except OnlineGateAbortImageGeneration as exc:
                            image_elapsed_ms = (
                                time.perf_counter() - image_start
                            ) * 1000.0
                            profiling_events.append(
                                {
                                    "stage": "image_generation",
                                    "iteration": iteration + 1,
                                    "sample_id": str(sample_id)
                                    if sample_id is not None
                                    else None,
                                    "trial_id": trial_id,
                                    "elapsed_ms": image_elapsed_ms,
                                    "gated_abort": True,
                                    "error": str(exc),
                                }
                            )
                            force_wo_after_gate = True
                            current_mode = "text"
                        except Exception as exc:
                            traceback.print_exc()
                            print(
                                f"Rank {base.d_rank()} error during image generation: {exc}"
                            )
                            current_mode = "text"

                    pbar.update(1)

        prediction_solution = "\n".join(
            filter(None, (text.strip() for text in collected_texts))
        ).strip()
        gate.finalize_trial(sample_id, trial_id)
        return reasoning_steps, prediction_solution, segment_infos, profiling_events

    @staticmethod
    def _compute_answer_logprob(
        segments: List[SegmentTextInfo],
        answer_spans: List[Optional[AnswerSpan]],
    ) -> float:
        selected_values: List[float] = []
        for span in answer_spans:
            if span is None:
                continue
            if span.segment_index < 0 or span.segment_index >= len(segments):
                continue
            token_values = segments[span.segment_index].token_logprobs
            token_slice = token_values[span.token_start : span.token_end]
            selected_values.extend(token_slice)
        if not selected_values:
            return 0.0
        return float(sum(selected_values))

    def _select_candidate(
        self,
        candidates: List[ReasoningCandidate],
        logprob_mode: str,
    ) -> Tuple[ReasoningCandidate, Counter, str]:
        """
            先做 majority voting（signature 计数）
            如有并列，用 candidates 里最早出现的 signature
            最终直接返回该 signature 的第一个候选（不再用 logprob 排序）
        Majority voting by candidate.signature.
        If multiple signatures tie for top votes, pick the one whose FIRST occurrence
        appears earliest in `candidates`.
        Then, within the chosen signature, return the FIRST occurrence candidate
        (no logprob tie-break).
        """
        score_mode = logprob_mode

        signature_counts = Counter(candidate.signature for candidate in candidates)
        best_signature, best_votes = max(
            signature_counts.items(), key=lambda item: item[1]
        )
        for candidate in candidates:
            if candidate.signature == best_signature:
                return candidate, signature_counts, score_mode
        return candidates[0], signature_counts, score_mode

    def run_best_of_n(
        self,
        inputs: List[Union[str, Image.Image]],
        system_prompt: Optional[str],
        best_of_n: int,
        logprob_mode: str,
        seed_base: Optional[int],
        seed_offset: int,
        seed_mode: str,
        sample_index: int,
        seed_stride: int,
        sample_id: Optional[str],
        **reasoning_kwargs,
    ) -> Tuple[ReasoningCandidate, List[ReasoningCandidate], Counter, str]:
        inference_kwargs = reasoning_kwargs.get("inference_kwargs", {})
        max_iterations = reasoning_kwargs.get("max_iterations", 10)
        verbose_iter = reasoning_kwargs.get("verbose_iter", False)
        verbose_image = reasoning_kwargs.get("verbose_image", False)

        candidates: List[ReasoningCandidate] = []
        if seed_base is not None and seed_mode == "per_sample":
            base.set_random_seed(seed_base + seed_offset + sample_index * seed_stride)
        for trial in range(best_of_n):
            print(f"SC {trial}")
            trial_seed: Optional[int] = None
            if seed_base is not None and seed_mode == "per_trial":
                trial_seed = (
                    seed_base + seed_offset + sample_index * seed_stride + trial
                )
                base.set_random_seed(trial_seed)
            steps, solution, segment_infos, profiling_log = self._run_single_trace(
                inputs=inputs,
                system_prompt=system_prompt,
                max_iterations=max_iterations,
                verbose_iter=verbose_iter,
                verbose_image=verbose_image,
                inference_kwargs=inference_kwargs,
                sample_id=sample_id,
                trial_id=trial,
            )
            answers, signature, answer_spans = extract_answers_and_signature(
                segment_infos
            )
            answer_only_logprob = self._compute_answer_logprob(
                segment_infos, answer_spans
            )
            if answer_only_logprob == 0.0 and any(
                span is not None for span in answer_spans
            ):
                # debug_spans = []
                for span in answer_spans:
                    if span is None:
                        continue
                    tokens = segment_infos[span.segment_index].token_logprobs
                    nan_mask = segment_infos[span.segment_index].token_logprob_nan_mask
                    texts = segment_infos[span.segment_index].token_texts
                    token_slice = tokens[span.token_start : span.token_end]
                    nan_slice = nan_mask[span.token_start : span.token_end]
                    ctx_start = max(span.token_start - 5, 0)
                    ctx_end = min(span.token_end + 5, len(tokens))
                    neighborhood = [
                        {
                            "text": texts[idx],
                            "logprob": tokens[idx],
                        }
                        for idx in range(ctx_start, ctx_end)
                    ]
                #     debug_spans.append({
                #         'segment_index': span.segment_index,
                #         'token_start': span.token_start,
                #         'token_end': span.token_end,
                #         'token_logprobs': token_slice,
                #         'token_nan_mask': nan_slice,
                #         'neighborhood': neighborhood,
                #     })
                # if debug_spans:
                #     print(f"[BoN Debug] zero answer logprob with spans: {json.dumps(debug_spans)}")
            reasoning_logprob_sum = float(
                sum(sum(seg.token_logprobs) for seg in segment_infos)
            )
            reasoning_token_count = sum(
                len(seg.token_logprobs) for seg in segment_infos
            )
            if reasoning_token_count > 0:
                reasoning_mean_logprob = reasoning_logprob_sum / reasoning_token_count
            else:
                reasoning_mean_logprob = 0.0
            candidates.append(
                ReasoningCandidate(
                    index=trial,
                    reasoning_steps=steps,
                    prediction_solution=solution,
                    answers=answers,
                    signature=signature,
                    reasoning_logprob=reasoning_logprob_sum,
                    reasoning_token_count=reasoning_token_count,
                    reasoning_mean_logprob=reasoning_mean_logprob,
                    answer_logprob=answer_only_logprob,
                    trial_seed=trial_seed,
                    answer_spans=answer_spans,
                    profiling_log=profiling_log,
                )
            )
        selected, counts, score_mode_used = self._select_candidate(
            candidates, logprob_mode
        )
        return selected, candidates, counts, score_mode_used


def _candidate_score(candidate: ReasoningCandidate, score_mode: str) -> float:
    if score_mode == "sum":
        return candidate.reasoning_logprob
    if score_mode == "reasoning_mean":
        return candidate.reasoning_mean_logprob
    return candidate.answer_logprob


def _span_to_dict(span: Optional[AnswerSpan]) -> Optional[Dict[str, int]]:
    if span is None:
        return None
    return {
        "segment_index": span.segment_index,
        "token_start": span.token_start,
        "token_end": span.token_end,
    }


def _pick_first_answer(candidate: ReasoningCandidate) -> Optional[str]:
    for ans in candidate.answers or []:
        if ans is not None and str(ans).strip() != "":
            return ans
    return None


def _compute_subset_predictions(
    candidates: List[ReasoningCandidate],
    score_mode: str,
) -> Dict[str, Dict[str, Any]]:
    subsets = [2**i for i in range(8) if 2**i <= len(candidates)]
    results: Dict[str, Dict[str, Any]] = {}

    for n in subsets:
        subset = candidates[:n]
        if not subset:
            continue

        # naive: first sample in order
        naive = subset[0]

        # majority: most frequent answer string, tie -> first occurrence
        answer_counts: Dict[Optional[str], int] = {}
        answer_first: Dict[Optional[str], ReasoningCandidate] = {}
        for cand in subset:
            ans = _pick_first_answer(cand)
            answer_counts[ans] = answer_counts.get(ans, 0) + 1
            if ans not in answer_first:
                answer_first[ans] = cand
        max_count = max(answer_counts.values())
        majority_ans = next(
            ans for ans in answer_counts if answer_counts[ans] == max_count
        )
        majority = answer_first[majority_ans]

        # weighted: sum answer_logprob by answer string, tie -> first occurrence
        answer_scores: Dict[Optional[str], float] = {}
        for cand in subset:
            ans = _pick_first_answer(cand)
            answer_scores[ans] = answer_scores.get(ans, 0.0) + cand.answer_logprob
        max_score = max(answer_scores.values())
        weighted_ans = next(
            ans for ans in answer_scores if answer_scores[ans] == max_score
        )
        weighted = answer_first[weighted_ans]

        results[str(n)] = {
            "naive_index": naive.index,
            "naive_answer": _pick_first_answer(naive),
            "majority_index": majority.index,
            "majority_answer": _pick_first_answer(majority),
            "weighted_index": weighted.index,
            "weighted_answer": _pick_first_answer(weighted),
        }

    return results


def save_all_trial_reasoning(
    handler: Any,
    item: Dict[str, Any],
    candidates: List[ReasoningCandidate],
    item_output_dir: str,
    image_root: str,
    dataset_name: Optional[str],
):
    trials_root = os.path.join(item_output_dir, "bon_trials")
    os.makedirs(trials_root, exist_ok=True)
    for cand in candidates:
        trial_dir = os.path.join(trials_root, f"trial_{cand.index}")
        os.makedirs(trial_dir, exist_ok=True)
        handler.save_results(
            cand.reasoning_steps,
            item,
            trial_dir,
            image_root=image_root,
            profiling_log=cand.profiling_log,
            dataset_name=dataset_name,
        )
        cand.output_subdir = os.path.relpath(trial_dir, item_output_dir)


def save_best_of_n_summary(
    item_output_dir: str,
    best_of_n: int,
    logprob_mode: str,
    score_mode_used: str,
    selected: ReasoningCandidate,
    candidates: List[ReasoningCandidate],
    vote_counts: Counter,
):
    signature_votes = [
        {
            "signature": list(sig),
            "count": count,
        }
        for sig, count in vote_counts.items()
    ]
    payload = {
        "best_of_n": best_of_n,
        "logprob_mode": logprob_mode,
        "score_mode_used": score_mode_used,
        "selected_index": selected.index,
        "signature_votes": signature_votes,
        "selected_answers": selected.answers,
        "selected_reasoning_logprob": selected.reasoning_logprob,
        "selected_reasoning_token_count": selected.reasoning_token_count,
        "selected_reasoning_mean_logprob": selected.reasoning_mean_logprob,
        "selected_answer_logprob": selected.answer_logprob,
        "selected_score_logprob": _candidate_score(selected, score_mode_used),
        "selected_result_subdir": selected.output_subdir,
        "selected_answer_spans": [
            _span_to_dict(span) for span in (selected.answer_spans or [])
        ],
        "tts_predictions": _compute_subset_predictions(candidates, score_mode_used),
        "candidates": [
            {
                "index": cand.index,
                "answers": cand.answers,
                "signature": list(cand.signature),
                "reasoning_logprob": cand.reasoning_logprob,
                "reasoning_token_count": cand.reasoning_token_count,
                "reasoning_mean_logprob": cand.reasoning_mean_logprob,
                "answer_logprob": cand.answer_logprob,
                "score_logprob": _candidate_score(cand, score_mode_used),
                "is_selected": cand.index == selected.index,
                "result_subdir": cand.output_subdir,
                "answer_spans": [
                    _span_to_dict(span) for span in (cand.answer_spans or [])
                ],
                "prediction_solution": cand.prediction_solution,
            }
            for cand in candidates
        ],
    }
    output_path = os.path.join(item_output_dir, "reasoning_result_bon.json")
    with open(output_path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)


def _sample_output_dirname(item_id: Any, sample_row_index: int) -> str:
    return f"{int(sample_row_index):05d}__{str(item_id)}"


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="Run BAGEL inference with test-time scaling (best-of-n).",
        epilog="Outputs best reasoning trace plus BoN summary per sample.",
    )
    parser.add_argument(
        "--dataset_type",
        type=str,
        required=True,
        choices=["mathcanvas", "uni"],
        help="Dataset type; picks the appropriate handler.",
    )
    parser.add_argument(
        "--dataset_name", type=str, help="Dataset name (default: matches type)."
    )
    parser.add_argument(
        "--input_path", type=str, required=True, help="Input data file path."
    )
    parser.add_argument(
        "--checkpoint_dir", type=str, required=True, help="Checkpoint directory."
    )
    parser.add_argument(
        "--output_dir", type=str, required=True, help="Where to store outputs."
    )
    parser.add_argument(
        "--checkpoint_file",
        type=str,
        default="model.safetensors",
        help="Checkpoint filename.",
    )
    parser.add_argument(
        "--model_path",
        type=str,
        required=True,
        help="Base model config/tokenizer path.",
    )
    parser.add_argument(
        "--image_root",
        type=str,
        required=True,
        help="Root directory for images referenced in the dataset.",
    )

    parser.add_argument(
        "--add_timestamp",
        type=str,
        choices=["true", "false"],
        default="true",
        help="Append timestamp to output directory.",
    )
    parser.add_argument(
        "--run_description",
        type=str,
        default="",
        help="Optional suffix for the run directory.",
    )
    parser.add_argument(
        "--verbose_iter",
        action="store_true",
        help="Show reasoning progress bar per sample.",
    )
    parser.add_argument(
        "--verbose_image", action="store_true", help="Show image denoising progress."
    )
    parser.add_argument(
        "--max_iterations",
        type=int,
        default=10,
        help="Maximum reasoning steps per sample.",
    )
    parser.add_argument(
        "--skip_completed",
        action="store_true",
        help="Skip samples that already have outputs.",
    )

    parser.add_argument(
        "--do_sample",
        type=str,
        choices=["true", "false"],
        default="true",
        help="Use sampling for text generation.",
    )
    parser.add_argument(
        "--text_temperature", type=float, default=0.3, help="Text sampling temperature."
    )
    parser.add_argument(
        "--cfg_text_scale", type=float, default=4.0, help="CFG scale for text prompts."
    )
    parser.add_argument(
        "--cfg_img_scale", type=float, default=2.0, help="CFG scale for image prompts."
    )
    parser.add_argument(
        "--cfg_interval",
        type=float,
        nargs=2,
        default=[0.0, 1.0],
        help="CFG application interval in [0,1].",
    )
    parser.add_argument(
        "--timestep_shift",
        type=float,
        default=3.0,
        help="Flow timestep shift parameter.",
    )
    parser.add_argument(
        "--num_timesteps", type=int, default=50, help="Number of denoising timesteps."
    )
    parser.add_argument(
        "--cfg_renorm_min", type=float, default=0.0, help="Minimum CFG renorm factor."
    )
    parser.add_argument(
        "--cfg_renorm_type",
        type=str,
        default="text_channel",
        choices=["global", "channel", "text_channel"],
        help="CFG renorm strategy.",
    )
    parser.add_argument(
        "--enable_taylorseer",
        type=str,
        choices=["true", "false"],
        default="false",
        help="Enable TaylorSeer caching.",
    )

    parser.add_argument(
        "--best_of_n",
        type=int,
        default=4,
        help="Number of reasoning traces per sample.",
    )
    parser.add_argument(
        "--bon_seed_offset",
        type=int,
        default=0,
        help="Offset added to per-trace random seed.",
    )
    parser.add_argument(
        "--seed", type=int, default=None, help="Optional base random seed."
    )
    parser.add_argument(
        "--seed_mode",
        type=str,
        choices=["global", "per_sample", "per_trial"],
        default="global",
        help="Seed strategy: global=one seed for whole run; per_sample=resets per item; per_trial=resets per trial.",
    )
    parser.add_argument(
        "--seed_stride",
        type=int,
        default=1000,
        help="Stride for per-sample seed: seed = base + offset + sample_index * stride (+ trial).",
    )
    parser.add_argument(
        "--bon_logprob_mode",
        type=str,
        choices=["sum", "answer"],
        default="answer",
        help="Scoring mode: 'sum' uses per-token average reasoning logprob; 'answer' only considers the segment containing the extracted answer.",
    )

    parser.add_argument(
        "--disable_tf32",
        action="store_true",
        help="Disable TF32 for debugging precision differences across GPUs.",
    )
    parser.add_argument(
        "--deterministic",
        action="store_true",
        help="Enable deterministic CUDA algorithms for debugging.",
    )
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    if args.best_of_n < 1:
        raise ValueError("best_of_n must be >= 1")

    if args.disable_tf32:
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
    if args.deterministic:
        torch.use_deterministic_algorithms(True)

    args.add_timestamp = args.add_timestamp.lower() == "true"
    args.do_sample = args.do_sample.lower() == "true"
    args.enable_taylorseer = args.enable_taylorseer.lower() == "true"

    rank = base.setup_distributed()
    world_size = base.d_world_size()
    if args.seed is not None:
        base_seed = args.seed
        base.set_random_seed(base_seed)
    else:
        base_seed = None

    if args.dataset_type == "mathcanvas":
        args.dataset_name = "mathcanvas"
        handler = base.MathCanvasHandler()
    elif args.dataset_type == "uni":
        handler = base.UniHandler()
    else:
        raise ValueError(f"Unsupported dataset type: {args.dataset_type}")

    INFERENCE_HYPERPARAMS = dict(
        do_sample=args.do_sample,
        text_temperature=args.text_temperature,
        cfg_text_scale=args.cfg_text_scale,
        cfg_img_scale=args.cfg_img_scale,
        cfg_interval=args.cfg_interval,
        timestep_shift=args.timestep_shift,
        num_timesteps=args.num_timesteps,
        cfg_renorm_min=args.cfg_renorm_min,
        cfg_renorm_type=args.cfg_renorm_type,
        enable_taylorseer=args.enable_taylorseer,
    )
    if rank == 0:
        print("Inference hyperparameters:")
        for k, v in INFERENCE_HYPERPARAMS.items():
            print(f"  {k}: {v}")
        print(f"Best-of-N: {args.best_of_n}")

    output_path = os.path.join(args.output_dir, args.dataset_name)
    if args.run_description:
        output_path = os.path.join(
            output_path, args.run_description
        )  # f"{output_path}_{args.run_description}"
    if args.add_timestamp:
        sync_timestamp = base.get_synchronized_timestamp()
        output_path = os.path.join(
            output_path, sync_timestamp
        )  # f"{output_path}_{sync_timestamp}"
    metric_dumper = get_metric_dumper()
    metric_run_group = os.path.basename(os.path.normpath(args.output_dir))
    metric_run_id = os.path.relpath(output_path, args.output_dir)
    metric_dumper.configure_run(run_group=metric_run_group, run_id=metric_run_id)
    if rank == 0 and metric_dumper.enabled:
        print(
            f"Metric dump dir: {metric_dumper.dump_dir / metric_run_group / metric_run_id}"
        )

    if rank == 0:
        os.makedirs(output_path, exist_ok=True)
        args_file_path = os.path.join(output_path, "inference_args.json")
        current_args_dict = vars(args)
        if os.path.exists(args_file_path):
            print(
                f"Found existing arguments file: {args_file_path}. Verifying consistency..."
            )
            try:
                with open(args_file_path, "r", encoding="utf-8") as f:
                    previous_args_dict = json.load(f)
                comp_prev = previous_args_dict.copy()
                comp_curr = current_args_dict.copy()
                for key in ["verbose_iter", "verbose_image", "input_path"]:
                    comp_prev.pop(key, None)
                    comp_curr.pop(key, None)
                if comp_prev != comp_curr:
                    print("\nERROR: Argument mismatch with previous run.", flush=True)
                    base.d_barrier()
                    return
                else:
                    print("Arguments are consistent. Resuming inference run.")
            except (json.JSONDecodeError, OSError) as exc:
                print(
                    f"Warning: Could not parse existing arguments file: {exc}. Overwriting."
                )
                with open(args_file_path, "w", encoding="utf-8") as f:
                    json.dump(current_args_dict, f, indent=4)
        else:
            print("No existing arguments file found. Saving current arguments.")
            with open(args_file_path, "w", encoding="utf-8") as f:
                json.dump(current_args_dict, f, indent=4)
    base.d_barrier()

    model, vae_model, tokenizer, vae_transform, vit_transform, new_token_ids = (
        base.setup_model(
            args.checkpoint_dir, rank, args.checkpoint_file, args.model_path
        )
    )
    inferencer = base.InterleaveInferencer(
        model, vae_model, tokenizer, vae_transform, vit_transform, new_token_ids
    )
    reasoner = BestOfNReasoner(inferencer)

    all_eval_data: List[Dict[str, Any]] = []
    if rank == 0:
        print(
            f"Using '{args.dataset_type}' handler to load data from {args.input_path}..."
        )
        all_eval_data = handler.load_data(args.input_path)
        for row_index, item in enumerate(all_eval_data):
            item["_sample_row_index"] = row_index
            item["_sample_output_dirname"] = _sample_output_dirname(
                item.get("id"), row_index
            )
        print(f"Loaded {len(all_eval_data)} total items.")
        if not args.skip_completed:
            print("Filtering out already completed items...")
            initial_count = len(all_eval_data)
            all_eval_data = [
                item
                for item in all_eval_data
                if not os.path.exists(
                    os.path.join(
                        output_path,
                        str(item.get("_sample_output_dirname")),
                        "reasoning_result.json",
                    )
                )
            ]
            print(
                f"Skipped {initial_count - len(all_eval_data)} completed items. {len(all_eval_data)} items remaining."
            )
        print(f"Processing all {len(all_eval_data)} items without sampling.")
    if not base.DIST_ENABLED:
        eval_data_to_process = all_eval_data
    else:
        data_to_distribute = [all_eval_data] if rank == 0 else [None]
        base.d_broadcast_object_list(data_to_distribute, src=0)
        eval_data_to_process = data_to_distribute[0]

    if not base.DIST_ENABLED:
        local_eval_data = eval_data_to_process
        start_index, end_index = 0, len(local_eval_data)
    else:
        total_items = len(eval_data_to_process)
        items_per_gpu = (total_items + world_size - 1) // world_size
        start_index = rank * items_per_gpu
        end_index = min(start_index + items_per_gpu, total_items)
        local_eval_data = eval_data_to_process[start_index:end_index]

    print(
        f"Rank {rank}/{world_size}: Processing {len(local_eval_data)} items (from index {start_index} to {end_index - 1})."
    )
    base.d_barrier()

    progress_bar = (
        tqdm(local_eval_data, desc=f"Rank {rank} Inference", position=rank)
        if not args.verbose_iter
        else tqdm(local_eval_data, desc=f"Rank {rank} Inference", disable=(rank != 0))
    )

    for local_idx, item in enumerate(progress_bar):
        item_id = item.get("id", f"item_{base.timestamp()}")
        sample_index = int(item.get("_sample_row_index", start_index + local_idx))
        item_output_dir = os.path.join(
            output_path,
            str(
                item.get(
                    "_sample_output_dirname",
                    _sample_output_dirname(item_id, sample_index),
                )
            ),
        )
        if rank == 0:
            os.makedirs(item_output_dir, exist_ok=True)
        base.d_barrier()

        try:
            inputs = handler.prepare_input(
                item, dataset_name=args.dataset_name, image_root=args.image_root
            )
            selected, candidates, vote_counts, score_mode_used = reasoner.run_best_of_n(
                inputs=inputs,
                system_prompt=None,
                best_of_n=args.best_of_n,
                logprob_mode=args.bon_logprob_mode,
                seed_base=base_seed,
                seed_offset=args.bon_seed_offset,
                seed_mode=args.seed_mode,
                sample_index=sample_index,
                seed_stride=args.seed_stride,
                sample_id=str(item_id),
                max_iterations=args.max_iterations,
                verbose_iter=args.verbose_iter,
                verbose_image=args.verbose_image,
                inference_kwargs=INFERENCE_HYPERPARAMS,
            )
            save_all_trial_reasoning(
                handler,
                item,
                candidates,
                item_output_dir,
                args.image_root,
                args.dataset_name,
            )
            handler.save_results(
                selected.reasoning_steps,
                item,
                item_output_dir,
                image_root=args.image_root,
                profiling_log=selected.profiling_log,
                dataset_name=args.dataset_name,
            )
            save_best_of_n_summary(
                item_output_dir,
                args.best_of_n,
                args.bon_logprob_mode,
                score_mode_used,
                selected,
                candidates,
                vote_counts,
            )
        except Exception as exc:
            print(f"Rank {rank} failed to process item {item_id}. Error: {exc}")
            traceback.print_exc()
            continue

    print(f"Rank {rank} has completed all assigned tasks.")
    metric_dumper.flush()  # wait for all async jsonl writes to finish
    base.d_barrier()
    if rank == 0:
        print("\nBest-of-N batch inference completed across all GPUs!")


if __name__ == "__main__":
    main()
