# Copyright 2025 Bytedance Ltd. and/or its affiliates.
# SPDX-License-Identifier: Apache-2.0

import copy
import os
from typing import List, Tuple, Optional, Dict, Any

import torch
import torch.nn.functional as F
from torch import nn
from torch.nn.attention.flex_attention import create_block_mask
from transformers.configuration_utils import PretrainedConfig
from transformers.modeling_utils import PreTrainedModel

from data.data_utils import (
    create_sparse_mask,
    get_flattened_position_ids_extrapolate,
    get_flattened_position_ids_interpolate,
    patchify,
)
from online_gate import OnlineGateAbortImageGeneration, get_online_gate_controller
from .qwen2_navit import NaiveCache
from .modeling_utils import MLPconnector, TimestepEmbedder, PositionEmbedding
from modeling.cache_utils.taylorseer import cache_init
from runtime_metrics import get_metric_dumper

from tqdm import tqdm


_METRIC_VIT_PRE_LLM_SUMMARY = os.environ.get(
    "BAGEL_METRIC_VIT_PRE_LLM_SUMMARY", "1"
).lower() in {"1", "true", "yes", "on"}
_METRIC_TEXT_VIT_DOT_SUMMARY = os.environ.get(
    "BAGEL_METRIC_TEXT_VIT_DOT_SUMMARY", "1"
).lower() in {"1", "true", "yes", "on"}
_METRIC_INPUT_TEXT_VIT_DOT_SUMMARY = os.environ.get(
    "BAGEL_METRIC_INPUT_TEXT_VIT_DOT_SUMMARY", "1"
).lower() in {"1", "true", "yes", "on"}
_METRIC_DIFFUSION_STEP_METRICS = os.environ.get(
    "BAGEL_METRIC_DIFFUSION_STEP_METRICS", "1"
).lower() in {"1", "true", "yes", "on"}


class BagelConfig(PretrainedConfig):
    def __init__(
        self,
        visual_gen=True,
        visual_und=True,
        llm_config=None,
        vit_config=None,
        vae_config=None,
        latent_patch_size=2,
        max_latent_size=32,
        vit_max_num_patch_per_side=70,
        connector_act="gelu_pytorch_tanh",
        interpolate_pos=False,
        timestep_shift=1.0,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.visual_gen = visual_gen
        self.visual_und = visual_und
        self.llm_config = llm_config
        self.vit_config = vit_config
        self.vae_config = vae_config
        self.latent_patch_size = latent_patch_size
        self.max_latent_size = max_latent_size
        self.vit_max_num_patch_per_side = vit_max_num_patch_per_side
        self.connector_act = connector_act
        self.interpolate_pos = interpolate_pos
        self.timestep_shift = timestep_shift


class Bagel(PreTrainedModel):
    config_class = BagelConfig
    base_model_prefix = "bagel"

    def __init__(self, language_model, vit_model, config: BagelConfig):
        super().__init__(config)
        self.language_model = language_model
        self.hidden_size = config.llm_config.hidden_size
        self.use_moe = "Mo" in config.llm_config.layer_module
        self.num_heads = config.llm_config.num_attention_heads

        if config.visual_gen:
            self.latent_patch_size = config.latent_patch_size
            self.timestep_shift = config.timestep_shift
            self.latent_downsample = (
                config.vae_config.downsample * config.latent_patch_size
            )
            self.max_latent_size = config.max_latent_size
            self.latent_channel = config.vae_config.z_channels
            self.patch_latent_dim = self.latent_patch_size**2 * self.latent_channel
            self.time_embedder = TimestepEmbedder(self.hidden_size)
            self.vae2llm = nn.Linear(self.patch_latent_dim, self.hidden_size)
            self.llm2vae = nn.Linear(self.hidden_size, self.patch_latent_dim)
            self.latent_pos_embed = PositionEmbedding(
                self.max_latent_size, self.hidden_size
            )

        if config.visual_und:
            self.vit_model = vit_model
            self.vit_patch_size = config.vit_config.patch_size
            self.vit_max_num_patch_per_side = config.vit_max_num_patch_per_side
            self.vit_hidden_size = config.vit_config.hidden_size
            self.connector = MLPconnector(
                self.vit_hidden_size, self.hidden_size, config.connector_act
            )
            self.vit_pos_embed = PositionEmbedding(
                self.vit_max_num_patch_per_side, self.hidden_size
            )

        if config.interpolate_pos:
            self.get_flattened_position_ids = get_flattened_position_ids_interpolate
        else:
            self.get_flattened_position_ids = get_flattened_position_ids_extrapolate

        self.config = config
        self._init_weights()

    def _init_weights(self):
        if self.config.visual_gen:
            nn.init.constant_(self.llm2vae.weight, 0)
            nn.init.constant_(self.llm2vae.bias, 0)

    def forward(
        self,
        sequence_length: int,
        packed_text_ids: torch.LongTensor,
        packed_text_indexes: torch.LongTensor,
        sample_lens: List[int],
        packed_position_ids: torch.LongTensor,
        nested_attention_masks: List[torch.Tensor] = None,
        split_lens: List[int] = None,
        attn_modes: List[str] = None,
        # for visual understanding
        ce_loss_indexes: Optional[torch.BoolTensor] = None,
        packed_label_ids: Optional[torch.LongTensor] = None,
        packed_vit_tokens: Optional[torch.Tensor] = None,
        packed_vit_token_indexes: Optional[torch.LongTensor] = None,
        packed_vit_position_ids: Optional[torch.LongTensor] = None,
        vit_token_seqlens: Optional[torch.IntTensor] = None,
        # for visual generation
        padded_latent: Optional[torch.Tensor] = None,
        patchified_vae_latent_shapes: Optional[List[Tuple[int, int]]] = None,
        packed_latent_position_ids: Optional[torch.LongTensor] = None,
        packed_vae_token_indexes: Optional[torch.LongTensor] = None,
        packed_timesteps: Optional[torch.LongTensor] = None,
        mse_loss_indexes: Optional[torch.BoolTensor] = None,
    ) -> torch.Tensor:
        """
        Args:
            sequence_length: length of sequence.
            packed_text_ids: 1-D int tensor, packed text token ids.
            packed_text_indexes: 1-D int tensor, packed text token indexes in sequence.
            sample_lens: A list of N ints, length of each sample in packed_sequence.
            nested_attention_masks: A list of N 2-D float tensor,  where 0.0 means attention and
                -inf means ignore.
            packed_position_ids: packed 1-D positions, an image has only one global position shared
                by all latent tokens.

            packed_vit_tokens: packed patchified image tokens for vit model.
            packed_vit_position_ids: 1-D int tensor, the position of each token for vit model.
            packed_vit_token_indexes: 1-D int tensor, packed vit token indexes in sequence.
            vit_token_seqlens: 1-D int tensor, the length of each image tokens for vit model.
            packed_label_ids: 1-D int tensor, packed label token ids.
            ce_loss_indexes: 1-D bool tensor, where to compute ce loss.

            padded_latent: padded latent from VAE encoder.
            patchified_vae_latent_shapes: A list of (h, w) tuples, patchfied latent shapes of each image.
            packed_latent_position_ids: 1-D int tensor, the position of each token for latent.
            packed_vae_token_indexes: 1-D int tensor, padded image token indexes in sequence.
            packed_timesteps: 1-D float tensor, flow timesteps. 0 indicates use clean image.
            mse_loss_indexes: 1-D bool tensor, where to compute mse loss.
        """
        packed_text_embedding = self.language_model.model.embed_tokens(packed_text_ids)
        packed_sequence = packed_text_embedding.new_zeros(
            size=(sequence_length, self.hidden_size)
        )
        packed_sequence[packed_text_indexes] = packed_text_embedding

        if nested_attention_masks is None:
            sparse_mask = create_sparse_mask(
                sample_lens, split_lens, attn_modes, packed_text_embedding.device
            )
            seqlen = sum(sample_lens)
            block_mask = create_block_mask(
                sparse_mask,
                B=1,
                H=self.num_heads,
                Q_LEN=seqlen,
                KV_LEN=seqlen,
                device=packed_text_embedding.device,
                BLOCK_SIZE=128,
                _compile=True,
            )
            attention_mask = block_mask
        else:
            attention_mask = nested_attention_masks

        if self.config.visual_und:
            if vit_token_seqlens is None or len(vit_token_seqlens) == 0:
                print(
                    "Error: vit_token_seqlens is None or empty, but visual_und is enabled."
                )
            cu_seqlens = torch.nn.functional.pad(
                torch.cumsum(vit_token_seqlens, dim=0), (1, 0)
            )
            cu_seqlens = cu_seqlens.to(torch.int32)
            max_seqlen = torch.max(vit_token_seqlens).item()
            packed_vit_token_embed = self.vit_model(
                packed_pixel_values=packed_vit_tokens,
                packed_flattened_position_ids=packed_vit_position_ids,
                cu_seqlens=cu_seqlens,
                max_seqlen=max_seqlen,
            )
            packed_vit_token_embed = self.connector(packed_vit_token_embed)
            vit_token_pos_emb = self.vit_pos_embed(packed_vit_position_ids)
            packed_vit_token_embed = packed_vit_token_embed + vit_token_pos_emb
            packed_sequence[packed_vit_token_indexes] = packed_vit_token_embed

        if self.config.visual_gen:
            p = self.latent_patch_size
            packed_latent = []
            for latent, (h, w) in zip(padded_latent, patchified_vae_latent_shapes):
                latent = latent[:, : h * p, : w * p].reshape(
                    self.latent_channel, h, p, w, p
                )
                latent = torch.einsum("chpwq->hwpqc", latent).reshape(
                    -1, p * p * self.latent_channel
                )
                packed_latent.append(latent)
            packed_latent_clean = torch.cat(packed_latent, dim=0)

            noise = torch.randn_like(packed_latent_clean)
            packed_timesteps = torch.sigmoid(packed_timesteps)
            packed_timesteps = (
                self.timestep_shift
                * packed_timesteps
                / (1 + (self.timestep_shift - 1) * packed_timesteps)
            )
            packed_latent = (
                1 - packed_timesteps[:, None]
            ) * packed_latent_clean + packed_timesteps[:, None] * noise
            packed_timestep_embeds = self.time_embedder(packed_timesteps)
            latent_token_pos_emb = self.latent_pos_embed(packed_latent_position_ids)
            packed_latent = (
                self.vae2llm(packed_latent)
                + packed_timestep_embeds
                + latent_token_pos_emb
            )
            packed_sequence[packed_vae_token_indexes] = packed_latent

        extra_inputs = {}
        if self.use_moe:
            packed_und_token_indexes = packed_text_indexes
            if packed_vit_token_indexes is not None:
                packed_und_token_indexes = torch.cat(
                    [packed_text_indexes, packed_vit_token_indexes], dim=0
                )
            extra_inputs.update(
                packed_und_token_indexes=packed_und_token_indexes,
                packed_gen_token_indexes=packed_vae_token_indexes,
            )

        last_hidden_state = self.language_model(
            packed_sequence=packed_sequence,
            sample_lens=sample_lens,
            attention_mask=attention_mask,
            packed_position_ids=packed_position_ids,
            **extra_inputs,
        )

        mse = None
        if self.config.visual_gen:
            packed_mse_preds = self.llm2vae(last_hidden_state[mse_loss_indexes])
            target = (
                noise - packed_latent_clean
            )  # NOTE: v_t=dx_t/dt=x_1-x_0, pointing from data to noise
            has_mse = packed_timesteps > 0
            mse = (packed_mse_preds - target[has_mse]) ** 2

        ce = None
        if ce_loss_indexes is not None:
            packed_ce_preds = self.language_model.lm_head(
                last_hidden_state[ce_loss_indexes]
            )
            ce = F.cross_entropy(packed_ce_preds, packed_label_ids, reduction="none")

        return dict(mse=mse, ce=ce)

    def prepare_prompts(
        self, curr_kvlens, curr_rope, prompts, tokenizer, new_token_ids
    ):
        packed_text_ids = list()
        packed_text_position_ids = list()
        text_token_lens = list()
        packed_text_indexes = list()
        packed_key_value_indexes = list()

        curr = 0
        newlens, new_rope = list(), list()
        for prompt, curr_kvlen, curr_position_id in zip(
            prompts, curr_kvlens, curr_rope
        ):
            packed_key_value_indexes.extend(range(curr, curr + curr_kvlen))
            curr += curr_kvlen

            text_ids = tokenizer.encode(prompt)  # tokenizer 把每个词 变成id
            text_ids = (
                [new_token_ids["bos_token_id"]]
                + text_ids
                + [new_token_ids["eos_token_id"]]
            )  # 前后补上 BOS/EOS
            text_token_lens.append(len(text_ids))
            packed_text_ids.extend(text_ids)
            packed_text_position_ids.extend(
                range(curr_position_id, curr_position_id + len(text_ids))
            )
            packed_text_indexes.extend(range(curr, curr + len(text_ids)))
            newlens.append(curr_kvlen + len(text_ids))
            new_rope.append(curr_position_id + len(text_ids))
            curr += len(text_ids)

        generation_input = {
            "text_token_lens": torch.tensor(text_token_lens, dtype=torch.int),
            "packed_text_ids": torch.tensor(packed_text_ids, dtype=torch.long),
            "packed_text_position_ids": torch.tensor(
                packed_text_position_ids, dtype=torch.long
            ),
            "packed_text_indexes": torch.tensor(packed_text_indexes, dtype=torch.long),
            "packed_key_value_indexes": torch.tensor(
                packed_key_value_indexes, dtype=torch.long
            ),
            "key_values_lens": torch.tensor(curr_kvlens, dtype=torch.int),
        }

        return generation_input, newlens, new_rope

    @staticmethod
    def _is_gen_text_prefill(trace: Dict[str, Any]) -> bool:
        return (
            str(trace.get("context") or "").strip().lower() == "gen"
            and str(trace.get("stage") or "").strip() == "text_prefill"
        )

    @staticmethod
    def _is_gen_generated_image_visual_prefill(trace: Dict[str, Any]) -> bool:
        return (
            str(trace.get("context") or "").strip().lower() == "gen"
            and str(trace.get("stage") or "").strip() == "visual_prefill"
            and str(trace.get("label") or "").strip() == "generated_image"
        )

    @staticmethod
    def _is_gen_visual_prefill(trace: Dict[str, Any]) -> bool:
        return (
            str(trace.get("context") or "").strip().lower() == "gen"
            and str(trace.get("stage") or "").strip() == "visual_prefill"
        )

    @torch.no_grad
    def forward_cache_update_text(
        self,
        past_key_values: NaiveCache,
        packed_text_ids: torch.IntTensor,
        packed_text_position_ids: torch.LongTensor,
        text_token_lens: torch.LongTensor,
        packed_text_indexes: torch.LongTensor,
        packed_key_value_indexes: torch.LongTensor,
        key_values_lens: torch.IntTensor,
    ):
        packed_text_embedding = self.language_model.model.embed_tokens(packed_text_ids)
        trace = dict(getattr(past_key_values, "metric_trace", {}) or {})
        dumper = get_metric_dumper()
        pending_generated_text_prefill = None
        pending_input_text_prefill = None
        if (
            self._is_gen_text_prefill(trace)
            and dumper.save_tensors
            and dumper.should_write_jsonl(trace.get("sample_id"))
        ):
            text_embed_cpu = packed_text_embedding.detach().to(torch.float32).cpu()
            text_ids_cpu = packed_text_ids.detach().to(torch.long).cpu()
            pending_record = {
                "text_embedding": text_embed_cpu,
                "text_token_ids": text_ids_cpu,
                "iteration": trace.get("iteration"),
                "label": trace.get("label"),
            }
            if str(trace.get("label") or "").strip() == "generated_text":
                pending_generated_text_prefill = pending_record
            elif str(trace.get("label") or "").strip() == "input_text":
                pending_input_text_prefill = pending_record
            dumper.save_metric_tensor(
                "text_prefill_embedding",
                trace,
                {
                    "text_embedding": text_embed_cpu,
                    "text_token_ids": text_ids_cpu,
                },
            )

        extra_inputs = {}
        if self.use_moe:
            extra_inputs = {"mode": "und"}

        output = self.language_model.forward_inference(
            packed_query_sequence=packed_text_embedding,
            query_lens=text_token_lens,
            packed_query_position_ids=packed_text_position_ids,
            packed_query_indexes=packed_text_indexes,
            past_key_values=past_key_values,
            packed_key_value_indexes=packed_key_value_indexes,
            key_values_lens=key_values_lens,
            update_past_key_values=True,
            is_causal=True,
            **extra_inputs,
        )
        past_key_values = output.past_key_values
        if pending_generated_text_prefill is not None:
            past_key_values.pending_generated_text_prefill = (
                pending_generated_text_prefill
            )
        if pending_input_text_prefill is not None:
            past_key_values.pending_input_text_prefill = pending_input_text_prefill

        return past_key_values

    def prepare_vit_images(
        self, curr_kvlens, curr_rope, images, transforms, new_token_ids
    ):
        packed_vit_token_indexes = list()
        vit_token_seqlens, packed_vit_tokens, packed_vit_position_ids = (
            list(),
            list(),
            list(),
        )
        packed_text_ids, packed_text_indexes = list(), list()
        packed_seqlens, packed_position_ids, packed_indexes = list(), list(), list()
        packed_key_value_indexes = list()

        _curr = curr = 0
        newlens, new_rope = list(), list()
        for image, curr_kvlen, curr_position_id in zip(images, curr_kvlens, curr_rope):
            packed_key_value_indexes.extend(range(curr, curr + curr_kvlen))
            curr += curr_kvlen

            packed_text_ids.append(new_token_ids["start_of_image"])
            packed_text_indexes.append(_curr)
            packed_indexes.append(curr)
            curr += 1
            _curr += 1

            image_tensor = transforms(image)  # [3,518,518]
            vit_position_ids = self.get_flattened_position_ids(
                image_tensor.size(1),
                image_tensor.size(2),
                self.vit_patch_size,
                max_num_patches_per_side=self.vit_max_num_patch_per_side,
            )
            vit_tokens = patchify(image_tensor, self.vit_patch_size)  # [1369,588]
            packed_vit_tokens.append(vit_tokens)
            num_img_tokens = vit_tokens.shape[0]
            packed_vit_position_ids.append(vit_position_ids)
            vit_token_seqlens.append(num_img_tokens)
            packed_vit_token_indexes.extend(range(_curr, _curr + num_img_tokens))
            packed_indexes.extend(range(curr, curr + num_img_tokens))
            curr += num_img_tokens
            _curr += num_img_tokens

            packed_text_ids.append(new_token_ids["end_of_image"])
            packed_text_indexes.append(_curr)
            packed_indexes.append(curr)
            curr += 1
            _curr += 1

            packed_position_ids.extend([curr_position_id] * (num_img_tokens + 2))
            packed_seqlens.append(num_img_tokens + 2)
            newlens.append(curr_kvlen + num_img_tokens + 2)
            new_rope.append(curr_position_id + 1)

        generation_input = {
            "packed_text_ids": torch.tensor(packed_text_ids, dtype=torch.long),
            "packed_text_indexes": torch.tensor(packed_text_indexes, dtype=torch.long),
            "vit_token_seqlens": torch.tensor(vit_token_seqlens, dtype=torch.int),
            "packed_vit_tokens": torch.cat(packed_vit_tokens, dim=0),
            "packed_vit_position_ids": torch.cat(packed_vit_position_ids, dim=0),
            "packed_vit_token_indexes": torch.tensor(
                packed_vit_token_indexes, dtype=torch.long
            ),
            "packed_position_ids": torch.tensor(packed_position_ids, dtype=torch.long),
            "packed_seqlens": torch.tensor(packed_seqlens, dtype=torch.int),
            "packed_indexes": torch.tensor(packed_indexes, dtype=torch.long),
            "packed_key_value_indexes": torch.tensor(
                packed_key_value_indexes, dtype=torch.long
            ),
            "key_values_lens": torch.tensor(curr_kvlens, dtype=torch.int),
        }

        return generation_input, newlens, new_rope

    @torch.no_grad
    def forward_cache_update_vit(
        self,
        past_key_values: NaiveCache,
        packed_text_ids: torch.LongTensor,
        packed_text_indexes: torch.LongTensor,
        packed_vit_tokens: torch.Tensor,
        packed_vit_token_indexes: torch.LongTensor,
        packed_vit_position_ids: torch.LongTensor,
        vit_token_seqlens: torch.IntTensor,
        packed_position_ids: torch.LongTensor,
        packed_seqlens: torch.IntTensor,
        packed_indexes: torch.LongTensor,
        packed_key_value_indexes: torch.LongTensor,
        key_values_lens: torch.IntTensor,
    ):
        packed_text_embedding = self.language_model.model.embed_tokens(packed_text_ids)
        packed_sequence = packed_text_embedding.new_zeros(
            (sum(packed_seqlens), self.hidden_size)
        )
        packed_sequence[packed_text_indexes] = packed_text_embedding

        cu_seqlens = torch.nn.functional.pad(
            torch.cumsum(vit_token_seqlens, dim=0), (1, 0)
        )
        cu_seqlens = cu_seqlens.to(torch.int32)
        max_seqlen = torch.max(vit_token_seqlens).item()
        packed_vit_token_embed = self.vit_model(
            packed_pixel_values=packed_vit_tokens,  # [1369,588]
            packed_flattened_position_ids=packed_vit_position_ids,
            cu_seqlens=cu_seqlens,
            max_seqlen=max_seqlen,
        )  # [1369,1152]
        packed_vit_token_embed = self.connector(packed_vit_token_embed)  # [1369, 3584]
        packed_vit_token_embed_pre_pos = packed_vit_token_embed
        pos_emb = self.vit_pos_embed(packed_vit_position_ids)
        packed_vit_token_embed = packed_vit_token_embed + pos_emb
        trace = dict(getattr(past_key_values, "metric_trace", {}) or {})
        dumper = get_metric_dumper()
        context = str(trace.get("context") or "").strip().lower()
        is_cfg_context = context in {"cfg_text", "cfg_img"}
        consumed_pending_text_prefill = False
        sample_id = trace.get("sample_id")
        want_vit_pre_llm_summary = (
            _METRIC_VIT_PRE_LLM_SUMMARY
            and dumper.should_write_jsonl_kind("vit_pre_llm_summary", sample_id)
        )
        want_text_vit_dot_summary = (
            _METRIC_TEXT_VIT_DOT_SUMMARY
            and dumper.should_write_jsonl_kind("text_vit_dot_summary", sample_id)
        )
        want_input_text_vit_dot_summary = (
            _METRIC_INPUT_TEXT_VIT_DOT_SUMMARY
            and dumper.should_write_jsonl_kind("input_text_vit_dot_summary", sample_id)
        )
        want_text_vit_tensors = dumper.save_tensors and dumper.should_write_jsonl(
            sample_id
        )
        if not is_cfg_context and (
            want_vit_pre_llm_summary
            or want_text_vit_dot_summary
            or want_input_text_vit_dot_summary
            or want_text_vit_tensors
        ):
            text_pre_llm = packed_text_embedding.detach().to(torch.float32)
            vit_pre_pos = packed_vit_token_embed_pre_pos.detach().to(torch.float32)
            vit_pre_llm = packed_vit_token_embed.detach().to(torch.float32)
            token_l2 = torch.norm(vit_pre_llm, dim=-1)
            center = vit_pre_llm.mean(dim=0)
            center_norm = torch.norm(center).clamp_min(1e-12)
            center_cos = (vit_pre_llm @ center) / (
                token_l2.clamp_min(1e-12) * center_norm
            )
            channel_var = vit_pre_llm.var(dim=0, unbiased=False)
            text_visual_cos_pre_pos = 0.0
            text_visual_cos_post_pos = 0.0
            if (
                text_pre_llm.shape[0] > 0
                and vit_pre_pos.shape[0] > 0
                and vit_pre_llm.shape[0] > 0
            ):
                text_center = text_pre_llm.mean(dim=0)
                vit_pre_pos_center = vit_pre_pos.mean(dim=0)
                vit_post_pos_center = vit_pre_llm.mean(dim=0)
                text_visual_cos_pre_pos = float(
                    F.cosine_similarity(
                        text_center.unsqueeze(0),
                        vit_pre_pos_center.unsqueeze(0),
                        dim=-1,
                        eps=1e-12,
                    )[0].item()
                )
                text_visual_cos_post_pos = float(
                    F.cosine_similarity(
                        text_center.unsqueeze(0),
                        vit_post_pos_center.unsqueeze(0),
                        dim=-1,
                        eps=1e-12,
                    )[0].item()
                )
            if want_vit_pre_llm_summary:
                dumper.write_jsonl(
                    "vit_pre_llm_summary",
                    {
                        k: trace.get(k)
                        for k in (
                            "sample_id",
                            "trial_id",
                            "iteration",
                            "stage",
                            "context",
                            "query_kind",
                            "label",
                        )
                    },
                    {
                        "num_vit_tokens": int(vit_pre_llm.shape[0]),
                        "token_dim": int(vit_pre_llm.shape[1])
                        if vit_pre_llm.dim() == 2
                        else 0,
                        "vit_pre_llm_token_l2_mean": float(token_l2.mean().item()),
                        "vit_pre_llm_token_l2_max": float(token_l2.max().item()),
                        "vit_pre_llm_center_cos_mean": float(center_cos.mean().item()),
                        "vit_pre_llm_center_cos_min": float(center_cos.min().item()),
                        "vit_pre_llm_center_cos_max": float(center_cos.max().item()),
                        "vit_pre_llm_channel_var_mean": float(
                            channel_var.mean().item()
                        ),
                        "text_visual_cos_pre_pos": text_visual_cos_pre_pos,
                        "text_visual_cos_post_pos": text_visual_cos_post_pos,
                    },
                )
            if self._is_gen_visual_prefill(trace) and (
                want_text_vit_dot_summary or want_text_vit_tensors
            ):
                cached_text_prefill = getattr(
                    past_key_values, "pending_generated_text_prefill", None
                )
                if (
                    isinstance(cached_text_prefill, dict)
                    and "text_embedding" in cached_text_prefill
                ):
                    text_embed_cpu = cached_text_prefill["text_embedding"].to(
                        torch.float32
                    )
                    vit_embed_cpu = vit_pre_llm.detach().to(torch.float32).cpu()
                    if (
                        text_embed_cpu.dim() == 2
                        and vit_embed_cpu.dim() == 2
                        and text_embed_cpu.shape[1] == vit_embed_cpu.shape[1]
                    ):
                        text_vit_dot = text_embed_cpu @ vit_embed_cpu.transpose(0, 1)
                        visual_score_from_text = text_vit_dot.mean(dim=0)
                        text_score_from_visual = text_vit_dot.mean(dim=1)
                        if want_text_vit_tensors:
                            dumper.save_metric_tensor(
                                "visual_prefill_vit_embedding",
                                trace,
                                {
                                    "vit_embedding_post_pos": vit_embed_cpu,
                                    "vit_position_ids": packed_vit_position_ids.detach()
                                    .to(torch.long)
                                    .cpu(),
                                },
                            )
                            dumper.save_metric_tensor(
                                "text_vit_dot_scores",
                                trace,
                                {
                                    "text_embedding_before_visual_prefill": text_embed_cpu,
                                    "text_embedding_before_image_generation": text_embed_cpu,
                                    "text_token_ids_before_visual_prefill": cached_text_prefill.get(
                                        "text_token_ids"
                                    ),
                                    "text_token_ids_before_image_generation": cached_text_prefill.get(
                                        "text_token_ids"
                                    ),
                                    "text_prefill_iteration": cached_text_prefill.get(
                                        "iteration"
                                    ),
                                    "text_prefill_label": cached_text_prefill.get(
                                        "label"
                                    ),
                                    "vit_embedding_after_visual_prefill": vit_embed_cpu,
                                    "vit_embedding_after_image_generation": vit_embed_cpu,
                                    "vit_position_ids_after_visual_prefill": packed_vit_position_ids.detach()
                                    .to(torch.long)
                                    .cpu(),
                                    "vit_position_ids_after_image_generation": packed_vit_position_ids.detach()
                                    .to(torch.long)
                                    .cpu(),
                                    "text_vit_dot": text_vit_dot,
                                    "visual_score_mean_over_text": visual_score_from_text,
                                    "text_score_mean_over_visual": text_score_from_visual,
                                },
                            )
                        if want_text_vit_dot_summary:
                            dumper.write_jsonl(
                                "text_vit_dot_summary",
                                {
                                    k: trace.get(k)
                                    for k in (
                                        "sample_id",
                                        "trial_id",
                                        "iteration",
                                        "stage",
                                        "context",
                                        "label",
                                    )
                                },
                                {
                                    "text_tokens": int(text_embed_cpu.shape[0]),
                                    "visual_tokens": int(vit_embed_cpu.shape[0]),
                                    "embed_dim": int(text_embed_cpu.shape[1]),
                                    "text_prefill_label": cached_text_prefill.get(
                                        "label"
                                    ),
                                    "dot_mean": float(text_vit_dot.mean().item()),
                                    "dot_max": float(text_vit_dot.max().item()),
                                    "dot_min": float(text_vit_dot.min().item()),
                                    "visual_score_mean": float(
                                        visual_score_from_text.mean().item()
                                    ),
                                    "text_score_mean": float(
                                        text_score_from_visual.mean().item()
                                    ),
                                },
                            )
                        consumed_pending_text_prefill = True
            if (
                self._is_gen_visual_prefill(trace)
                and str(trace.get("label") or "").strip() == "input_image"
                and (want_input_text_vit_dot_summary or want_text_vit_tensors)
            ):
                cached_input_text_prefill = getattr(
                    past_key_values, "pending_input_text_prefill", None
                )
                if (
                    isinstance(cached_input_text_prefill, dict)
                    and "text_embedding" in cached_input_text_prefill
                ):
                    text_embed_cpu = cached_input_text_prefill["text_embedding"].to(
                        torch.float32
                    )
                    vit_embed_cpu = vit_pre_llm.detach().to(torch.float32).cpu()
                    if (
                        text_embed_cpu.dim() == 2
                        and vit_embed_cpu.dim() == 2
                        and text_embed_cpu.shape[1] == vit_embed_cpu.shape[1]
                    ):
                        text_vit_dot = text_embed_cpu @ vit_embed_cpu.transpose(0, 1)
                        visual_score_from_text = text_vit_dot.mean(dim=0)
                        text_score_from_visual = text_vit_dot.mean(dim=1)
                        if want_text_vit_tensors:
                            dumper.save_metric_tensor(
                                "input_text_vit_dot_scores",
                                trace,
                                {
                                    "text_embedding_before_visual_prefill": text_embed_cpu,
                                    "text_token_ids_before_visual_prefill": cached_input_text_prefill.get(
                                        "text_token_ids"
                                    ),
                                    "text_prefill_iteration": cached_input_text_prefill.get(
                                        "iteration"
                                    ),
                                    "text_prefill_label": cached_input_text_prefill.get(
                                        "label"
                                    ),
                                    "vit_embedding_after_visual_prefill": vit_embed_cpu,
                                    "vit_position_ids_after_visual_prefill": packed_vit_position_ids.detach()
                                    .to(torch.long)
                                    .cpu(),
                                    "text_vit_dot": text_vit_dot,
                                    "visual_score_mean_over_text": visual_score_from_text,
                                    "text_score_mean_over_visual": text_score_from_visual,
                                },
                            )
                        if want_input_text_vit_dot_summary:
                            dumper.write_jsonl(
                                "input_text_vit_dot_summary",
                                {
                                    k: trace.get(k)
                                    for k in (
                                        "sample_id",
                                        "trial_id",
                                        "iteration",
                                        "stage",
                                        "context",
                                        "label",
                                    )
                                },
                                {
                                    "text_tokens": int(text_embed_cpu.shape[0]),
                                    "visual_tokens": int(vit_embed_cpu.shape[0]),
                                    "embed_dim": int(text_embed_cpu.shape[1]),
                                    "text_prefill_label": cached_input_text_prefill.get(
                                        "label"
                                    ),
                                    "dot_mean": float(text_vit_dot.mean().item()),
                                    "dot_max": float(text_vit_dot.max().item()),
                                    "dot_min": float(text_vit_dot.min().item()),
                                    "visual_score_mean": float(
                                        visual_score_from_text.mean().item()
                                    ),
                                    "text_score_mean": float(
                                        text_score_from_visual.mean().item()
                                    ),
                                },
                            )
        if consumed_pending_text_prefill and hasattr(
            past_key_values, "pending_generated_text_prefill"
        ):
            delattr(past_key_values, "pending_generated_text_prefill")
        if (
            hasattr(past_key_values, "pending_input_text_prefill")
            and str(trace.get("label") or "").strip() == "input_image"
        ):
            delattr(past_key_values, "pending_input_text_prefill")
        if packed_vit_token_embed.dtype != packed_sequence.dtype:
            packed_vit_token_embed = packed_vit_token_embed.to(packed_sequence.dtype)
        packed_sequence[packed_vit_token_indexes] = packed_vit_token_embed

        extra_inputs = {}
        if self.use_moe:
            extra_inputs = {"mode": "und"}

        output = self.language_model.forward_inference(
            packed_query_sequence=packed_sequence,
            query_lens=packed_seqlens,
            packed_query_position_ids=packed_position_ids,
            packed_query_indexes=packed_indexes,
            past_key_values=past_key_values,
            packed_key_value_indexes=packed_key_value_indexes,
            key_values_lens=key_values_lens,
            update_past_key_values=True,
            is_causal=False,
            **extra_inputs,
        )
        past_key_values = output.past_key_values
        if consumed_pending_text_prefill and hasattr(
            past_key_values, "pending_generated_text_prefill"
        ):
            delattr(past_key_values, "pending_generated_text_prefill")

        return past_key_values

    def prepare_vae_images(
        self, curr_kvlens, curr_rope, images, transforms, new_token_ids, timestep=0
    ):
        patchified_vae_latent_shapes, packed_vae_position_ids = list(), list()
        packed_vae_token_indexes = list()
        packed_text_ids, packed_text_indexes = list(), list()
        packed_seqlens, packed_position_ids, packed_indexes = list(), list(), list()
        packed_key_value_indexes = list()

        _curr = curr = 0
        vae_image_tensors = list()
        newlens, new_rope = list(), list()
        for image, curr_kvlen, curr_position_id in zip(images, curr_kvlens, curr_rope):
            packed_key_value_indexes.extend(range(curr, curr + curr_kvlen))
            curr += curr_kvlen

            packed_text_ids.append(new_token_ids["start_of_image"])
            packed_text_indexes.append(_curr)
            packed_indexes.append(curr)
            curr += 1
            _curr += 1

            image_tensor = transforms(image)  # 【3,512,512】
            vae_image_tensors.append(image_tensor)
            vae_posiiton_ids = self.get_flattened_position_ids(  # 把空间尺寸换算到 patch 网格 (h, w)。用 get_flattened_position_ids() 为这些 patch 生成位置编码。
                image_tensor.size(1),
                image_tensor.size(2),
                self.latent_downsample,
                max_num_patches_per_side=self.max_latent_size,
            )
            packed_vae_position_ids.append(vae_posiiton_ids)
            H, W = image_tensor.shape[1:]
            h = H // self.latent_downsample
            w = W // self.latent_downsample
            patchified_vae_latent_shapes.append((h, w))

            num_img_tokens = w * h  # 32*32
            packed_vae_token_indexes.extend(range(_curr, _curr + num_img_tokens))
            packed_indexes.extend(range(curr, curr + num_img_tokens))
            curr += num_img_tokens
            _curr += num_img_tokens

            packed_text_ids.append(new_token_ids["end_of_image"])
            packed_text_indexes.append(_curr)
            packed_indexes.append(curr)
            curr += 1
            _curr += 1

            packed_position_ids.extend([curr_position_id] * (num_img_tokens + 2))
            packed_seqlens.append(num_img_tokens + 2)
            newlens.append(curr_kvlen + num_img_tokens + 2)
            new_rope.append(curr_position_id + 1)

        image_sizes = [item.shape for item in vae_image_tensors]
        max_image_size = [max(item) for item in list(zip(*image_sizes))]
        padded_images = torch.zeros(size=(len(vae_image_tensors), *max_image_size))
        for i, image_tensor in enumerate(vae_image_tensors):
            padded_images[i, :, : image_tensor.shape[1], : image_tensor.shape[2]] = (
                image_tensor
            )

        generation_input = {
            "padded_images": padded_images,
            "patchified_vae_latent_shapes": patchified_vae_latent_shapes,
            "packed_vae_position_ids": torch.cat(packed_vae_position_ids, dim=0),
            "packed_timesteps": torch.tensor([timestep]),
            "packed_vae_token_indexes": torch.tensor(
                packed_vae_token_indexes, dtype=torch.long
            ),
            "packed_text_ids": torch.tensor(packed_text_ids, dtype=torch.long),
            "packed_text_indexes": torch.tensor(packed_text_indexes, dtype=torch.long),
            "packed_position_ids": torch.tensor(packed_position_ids, dtype=torch.long),
            "packed_seqlens": torch.tensor(packed_seqlens, dtype=torch.int),  # 1024+2
            "packed_indexes": torch.tensor(packed_indexes, dtype=torch.long),
            "packed_key_value_indexes": torch.tensor(
                packed_key_value_indexes, dtype=torch.long
            ),
            "key_values_lens": torch.tensor(curr_kvlens, dtype=torch.int),
        }

        return generation_input, newlens, new_rope

    @torch.no_grad
    def forward_cache_update_vae(
        self,
        vae_model,
        past_key_values: NaiveCache,
        padded_images: torch.Tensor,
        patchified_vae_latent_shapes: List,
        packed_vae_position_ids: torch.LongTensor,
        packed_timesteps: torch.Tensor,
        packed_vae_token_indexes: torch.LongTensor,
        packed_text_ids: torch.LongTensor,
        packed_text_indexes: torch.LongTensor,
        packed_position_ids: torch.LongTensor,
        packed_seqlens: torch.IntTensor,
        packed_indexes: torch.LongTensor,
        key_values_lens: torch.IntTensor,
        packed_key_value_indexes: torch.Tensor,
    ):
        packed_text_embedding = self.language_model.model.embed_tokens(packed_text_ids)
        packed_sequence = packed_text_embedding.new_zeros(
            (sum(packed_seqlens), self.hidden_size)
        )  # 1026，3584
        packed_sequence[packed_text_indexes] = packed_text_embedding  # 首和尾 0和1025

        padded_latent = vae_model.encode(padded_images.to(self.device))
        # 把 VAE 编码后的图像 latent 变成语言模型可读的 token
        p = self.latent_patch_size
        packed_latent = list()
        for latent, (h, w) in zip(padded_latent, patchified_vae_latent_shapes):
            latent = latent[:, : h * p, : w * p].reshape(
                self.latent_channel, h, p, w, p
            )
            latent = torch.einsum("chpwq->hwpqc", latent).reshape(
                -1, p * p * self.latent_channel
            )
            packed_latent.append(latent)
        packed_latent = torch.cat(packed_latent, dim=0)
        packed_pos_embed = self.latent_pos_embed(packed_vae_position_ids)
        packed_timestep_embeds = self.time_embedder(packed_timesteps)
        packed_latent = (
            self.vae2llm(packed_latent) + packed_timestep_embeds + packed_pos_embed
        )
        if packed_latent.dtype != packed_sequence.dtype:
            packed_latent = packed_latent.to(packed_sequence.dtype)
        packed_sequence[packed_vae_token_indexes] = packed_latent

        extra_inputs = {}
        if self.use_moe:
            extra_inputs = {
                "mode": "gen",
                "packed_vae_token_indexes": packed_vae_token_indexes,  # 1024
                "packed_text_indexes": packed_text_indexes,  # 首尾 2
            }

        output = self.language_model.forward_inference(
            packed_query_sequence=packed_sequence,
            query_lens=packed_seqlens,
            packed_query_position_ids=packed_position_ids,
            packed_query_indexes=packed_indexes,
            past_key_values=past_key_values,
            key_values_lens=key_values_lens,
            packed_key_value_indexes=packed_key_value_indexes,
            update_past_key_values=True,
            is_causal=False,
            **extra_inputs,
        )
        past_key_values = output.past_key_values

        return past_key_values

    def prepare_vae_latent(self, curr_kvlens, curr_rope, image_sizes, new_token_ids):
        packed_text_ids, packed_text_indexes = list(), list()
        packed_vae_position_ids, packed_vae_token_indexes, packed_init_noises = (
            list(),
            list(),
            list(),
        )
        packed_position_ids, packed_seqlens, packed_indexes = list(), list(), list()
        packed_key_value_indexes = list()

        query_curr = curr = 0
        for (H, W), curr_kvlen, curr_position_id in zip(
            image_sizes, curr_kvlens, curr_rope
        ):
            packed_key_value_indexes.extend(range(curr, curr + curr_kvlen))
            curr += curr_kvlen

            packed_text_ids.append(new_token_ids["start_of_image"])
            packed_text_indexes.append(query_curr)
            packed_indexes.append(curr)
            curr += 1
            query_curr += 1

            vae_posiiton_ids = self.get_flattened_position_ids(
                H,
                W,
                self.latent_downsample,
                max_num_patches_per_side=self.max_latent_size,
            )
            packed_vae_position_ids.append(vae_posiiton_ids)

            h, w = H // self.latent_downsample, W // self.latent_downsample
            num_image_tokens = h * w
            packed_init_noises.append(
                torch.randn(
                    num_image_tokens, self.latent_channel * self.latent_patch_size**2
                )
            )
            packed_vae_token_indexes.extend(
                range(query_curr, query_curr + num_image_tokens)
            )
            packed_indexes.extend(range(curr, curr + num_image_tokens))
            curr += num_image_tokens
            query_curr += num_image_tokens

            packed_text_ids.append(new_token_ids["end_of_image"])
            packed_text_indexes.append(query_curr)
            packed_indexes.append(curr)
            curr += 1
            query_curr += 1

            packed_position_ids.extend([curr_position_id] * (num_image_tokens + 2))
            packed_seqlens.append(num_image_tokens + 2)

        generation_input = {
            "packed_text_ids": torch.tensor(packed_text_ids, dtype=torch.long),
            "packed_text_indexes": torch.tensor(packed_text_indexes, dtype=torch.long),
            "packed_init_noises": torch.cat(packed_init_noises, dim=0),
            "packed_vae_position_ids": torch.cat(packed_vae_position_ids, dim=0),
            "packed_vae_token_indexes": torch.tensor(
                packed_vae_token_indexes, dtype=torch.long
            ),
            "packed_seqlens": torch.tensor(packed_seqlens, dtype=torch.int),
            "packed_position_ids": torch.tensor(packed_position_ids, dtype=torch.long),
            "key_values_lens": torch.tensor(curr_kvlens, dtype=torch.int),
            "packed_indexes": torch.tensor(packed_indexes, dtype=torch.long),
            "packed_key_value_indexes": torch.tensor(
                packed_key_value_indexes, dtype=torch.long
            ),
        }

        return generation_input

    def prepare_vae_latent_cfg(self, curr_kvlens, curr_rope, image_sizes):
        packed_position_ids, packed_indexes, packed_key_value_indexes = (
            list(),
            list(),
            list(),
        )

        query_curr = curr = 0
        for (H, W), curr_kvlen, curr_position_id in zip(
            image_sizes, curr_kvlens, curr_rope
        ):
            packed_key_value_indexes.extend(range(curr, curr + curr_kvlen))
            curr += curr_kvlen

            packed_indexes.append(curr)
            curr += 1
            query_curr += 1

            h, w = H // self.latent_downsample, W // self.latent_downsample
            num_image_tokens = h * w
            packed_indexes.extend(range(curr, curr + num_image_tokens))
            curr += num_image_tokens
            query_curr += num_image_tokens

            packed_indexes.append(curr)
            curr += 1
            query_curr += 1

            packed_position_ids.extend([curr_position_id] * (num_image_tokens + 2))

        generation_input = {
            "cfg_packed_position_ids": torch.tensor(
                packed_position_ids, dtype=torch.long
            ),
            "cfg_key_values_lens": torch.tensor(curr_kvlens, dtype=torch.int),
            "cfg_packed_query_indexes": torch.tensor(packed_indexes, dtype=torch.long),
            "cfg_packed_key_value_indexes": torch.tensor(
                packed_key_value_indexes, dtype=torch.long
            ),
        }

        return generation_input

    @torch.no_grad
    def generate_image(
        self,
        packed_text_ids: torch.LongTensor,
        packed_text_indexes: torch.LongTensor,
        packed_init_noises: torch.Tensor,
        packed_vae_position_ids: torch.LongTensor,
        packed_vae_token_indexes: torch.LongTensor,
        packed_seqlens: torch.IntTensor,
        packed_position_ids: torch.LongTensor,
        packed_indexes: torch.LongTensor,
        past_key_values: NaiveCache,
        key_values_lens: torch.IntTensor,
        packed_key_value_indexes: torch.LongTensor,
        num_timesteps: int = 24,
        timestep_shift: float = 1.0,
        cfg_renorm_min: float = 0.0,
        cfg_renorm_type: str = "global",
        cfg_interval: Optional[Tuple[float, float]] = (0.0, 1.0),
        # cfg_text
        cfg_text_scale: float = 1.0,
        cfg_text_packed_query_indexes: Optional[torch.LongTensor] = None,
        cfg_text_packed_position_ids: Optional[torch.LongTensor] = None,
        cfg_text_past_key_values: Optional[NaiveCache] = None,
        cfg_text_key_values_lens: Optional[torch.IntTensor] = None,
        cfg_text_packed_key_value_indexes: Optional[torch.LongTensor] = None,
        # cfg_img
        cfg_img_scale: float = 1.0,
        cfg_img_packed_query_indexes: Optional[torch.LongTensor] = None,
        cfg_img_packed_position_ids: Optional[torch.LongTensor] = None,
        cfg_img_past_key_values: Optional[NaiveCache] = None,
        cfg_img_key_values_lens: Optional[torch.IntTensor] = None,
        cfg_img_packed_key_value_indexes: Optional[torch.LongTensor] = None,
        cfg_type: str = "parallel",
        # cache_args
        enable_taylorseer=False,
        early_stop_sampled_steps: Optional[int] = None,
        verbose: bool = True,
    ):
        if enable_taylorseer:
            self.language_model.model.enable_taylorseer = True
            model_pred_cache_dic, model_pred_current = cache_init(self, num_timesteps)
            model_pred_text_cache_dic, model_pred_text_current = cache_init(
                self, num_timesteps
            )
            model_pred_img_cache_dic, model_pred_img_current = cache_init(
                self, num_timesteps
            )
        else:
            self.language_model.model.enable_taylorseer = False
            model_pred_cache_dic, model_pred_current = None, None
            model_pred_text_cache_dic, model_pred_text_current = None, None
            model_pred_img_cache_dic, model_pred_img_current = None, None
        dumper = get_metric_dumper()
        trace = dict(getattr(past_key_values, "metric_trace", {}) or {})
        should_dump_diffusion_metrics = (
            _METRIC_DIFFUSION_STEP_METRICS
            and dumper.should_write_jsonl_kind(
                "diffusion_step_metrics", trace.get("sample_id")
            )
        )

        if cfg_interval is None:
            cfg_interval_low, cfg_interval_high = 0.0, 1.0
        else:
            if len(cfg_interval) != 2:
                raise ValueError(f"cfg_interval must have 2 values, got {cfg_interval}")
            cfg_interval_low = float(cfg_interval[0])
            cfg_interval_high = float(cfg_interval[1])
            if not (0.0 <= cfg_interval_low <= cfg_interval_high <= 1.0):
                raise ValueError(
                    f"cfg_interval must satisfy 0 <= low <= high <= 1, got {cfg_interval}"
                )

        x_t = packed_init_noises
        prev_x_t_flat: Optional[torch.Tensor] = None
        final_temporal_lcp: float = 0.0

        timesteps = torch.linspace(1, 0, num_timesteps, device=x_t.device)
        timesteps = timestep_shift * timesteps / (1 + (timestep_shift - 1) * timesteps)
        dts = timesteps[:-1] - timesteps[1:]  # 计算相邻时间步的间隔 Δt（共 49 个）。
        timesteps = timesteps[:-1]
        # 一个step的去噪已经完成，和扩散模型一样，将原图减去这个预测的噪声，得到下一个阶段的输入。
        total_diffusion_steps = len(timesteps)
        gate = get_online_gate_controller()
        for i, t in tqdm(
            enumerate(timesteps), total=total_diffusion_steps, disable=not verbose
        ):
            diffusion_step_idx = i + 1
            diffusion_is_terminal = diffusion_step_idx == total_diffusion_steps
            for cache in (
                past_key_values,
                cfg_text_past_key_values,
                cfg_img_past_key_values,
            ):
                if cache is None:
                    continue
                cache_trace = dict(getattr(cache, "metric_trace", {}) or {})
                cache_trace["diffusion_step_idx"] = diffusion_step_idx
                cache_trace["diffusion_total_steps"] = total_diffusion_steps
                cache_trace["diffusion_is_terminal"] = diffusion_is_terminal
                cache.metric_trace = cache_trace

            timestep = torch.tensor([t] * x_t.shape[0], device=x_t.device)
            if t > cfg_interval_low and t <= cfg_interval_high:
                cfg_text_scale_ = cfg_text_scale
                cfg_img_scale_ = cfg_img_scale
            else:
                cfg_text_scale_ = 1.0
                cfg_img_scale_ = 1.0
            v_t, _flow_metrics = self._forward_flow(
                x_t=x_t,
                timestep=timestep,
                packed_vae_token_indexes=packed_vae_token_indexes,
                packed_vae_position_ids=packed_vae_position_ids,
                packed_text_ids=packed_text_ids,
                packed_text_indexes=packed_text_indexes,
                packed_position_ids=packed_position_ids,
                packed_indexes=packed_indexes,
                packed_seqlens=packed_seqlens,
                key_values_lens=key_values_lens,
                past_key_values=past_key_values,
                packed_key_value_indexes=packed_key_value_indexes,
                cfg_renorm_min=cfg_renorm_min,
                cfg_renorm_type=cfg_renorm_type,
                # cfg_text
                cfg_text_scale=cfg_text_scale_,
                cfg_text_packed_position_ids=cfg_text_packed_position_ids,
                cfg_text_packed_query_indexes=cfg_text_packed_query_indexes,
                cfg_text_key_values_lens=cfg_text_key_values_lens,
                cfg_text_past_key_values=cfg_text_past_key_values,
                cfg_text_packed_key_value_indexes=cfg_text_packed_key_value_indexes,
                # cfg_img
                cfg_img_scale=cfg_img_scale_,
                cfg_img_packed_position_ids=cfg_img_packed_position_ids,
                cfg_img_packed_query_indexes=cfg_img_packed_query_indexes,
                cfg_img_key_values_lens=cfg_img_key_values_lens,
                cfg_img_past_key_values=cfg_img_past_key_values,
                cfg_img_packed_key_value_indexes=cfg_img_packed_key_value_indexes,
                cfg_type=cfg_type,
                # cache
                model_pred_cache_dic=model_pred_cache_dic,
                model_pred_current=model_pred_current,
                model_pred_text_cache_dic=model_pred_text_cache_dic,
                model_pred_text_current=model_pred_text_current,
                model_pred_img_cache_dic=model_pred_img_cache_dic,
                model_pred_img_current=model_pred_img_current,
            )
            x_t = (
                x_t - v_t.to(x_t.device) * dts[i]
            )  # velocity pointing from data to noise
            if gate.enabled:
                decision = gate.maybe_decide_pre(
                    dict(getattr(past_key_values, "metric_trace", {}) or {})
                )
                if decision is not None and not bool(decision.get("choose_off")):
                    raise OnlineGateAbortImageGeneration(
                        f"online gate aborted image generation at diffusion step {diffusion_step_idx}"
                    )
            if should_dump_diffusion_metrics:
                curr_x_t_flat = x_t.detach().to(torch.float32).reshape(-1).cpu()
                if prev_x_t_flat is not None:
                    denom = torch.norm(prev_x_t_flat) * torch.norm(curr_x_t_flat)
                    if float(denom.item()) > 0.0:
                        final_temporal_lcp = float(
                            torch.dot(prev_x_t_flat, curr_x_t_flat).item()
                            / denom.item()
                        )
                    else:
                        final_temporal_lcp = 0.0
                prev_x_t_flat = curr_x_t_flat
            if early_stop_sampled_steps is not None and diffusion_step_idx >= int(
                early_stop_sampled_steps
            ):
                break

        if should_dump_diffusion_metrics:
            final_latent = x_t.detach().to(torch.float32)
            if final_latent.dim() >= 2 and final_latent.shape[0] > 0:
                spatial_var = final_latent.var(dim=0, unbiased=False)
                token_l2 = torch.norm(final_latent, dim=-1)
                latent_spatial_var_mean = float(spatial_var.mean().item())
                latent_token_l2_mean = float(token_l2.mean().item())
                num_latent_tokens = int(final_latent.shape[0])
                latent_dim = int(final_latent.shape[1])
            else:
                latent_spatial_var_mean = 0.0
                latent_token_l2_mean = 0.0
                num_latent_tokens = (
                    int(final_latent.shape[0]) if final_latent.dim() > 0 else 0
                )
                latent_dim = (
                    int(final_latent.shape[-1]) if final_latent.dim() > 0 else 0
                )
            dumper.write_jsonl(
                "diffusion_step_metrics",
                {
                    k: trace.get(k)
                    for k in ("sample_id", "trial_id", "iteration", "stage")
                },
                {
                    "num_latent_tokens": num_latent_tokens,
                    "latent_dim": latent_dim,
                    "latent_spatial_var_mean": latent_spatial_var_mean,
                    "latent_token_l2_mean": latent_token_l2_mean,
                    "temporal_lcp": final_temporal_lcp,
                },
            )

        if enable_taylorseer:
            del model_pred_cache_dic, model_pred_current
            del model_pred_text_cache_dic, model_pred_text_current
            del model_pred_img_cache_dic, model_pred_img_current

        if hasattr(self.language_model.model, "enable_taylorseer"):
            self.language_model.model.enable_taylorseer = False

        for layer in self.language_model.model.layers:
            if hasattr(layer, "enable_taylorseer"):
                delattr(layer, "enable_taylorseer")
            if hasattr(layer, "cache_dic"):
                delattr(layer, "cache_dic")
            if hasattr(layer, "current"):
                delattr(layer, "current")
        if hasattr(self.language_model.model, "cache_dic"):
            delattr(self.language_model.model, "cache_dic")
        if hasattr(self.language_model.model, "current"):
            delattr(self.language_model.model, "current")

        unpacked_latent = x_t.split((packed_seqlens - 2).tolist())
        return unpacked_latent

    @torch.no_grad
    def _forward_flow(
        self,
        x_t: torch.Tensor,
        timestep: torch.LongTensor,
        packed_vae_token_indexes: torch.LongTensor,
        packed_vae_position_ids: torch.LongTensor,
        packed_text_ids: torch.LongTensor,
        packed_text_indexes: torch.LongTensor,
        packed_indexes: torch.LongTensor,
        packed_position_ids: torch.LongTensor,
        packed_seqlens: torch.IntTensor,
        key_values_lens: torch.IntTensor,
        past_key_values: NaiveCache,
        packed_key_value_indexes: torch.LongTensor,
        cfg_renorm_min: float = 0.0,
        cfg_renorm_type: str = "global",
        # cfg_text
        cfg_text_scale: float = 1.0,
        cfg_text_packed_position_ids: Optional[torch.LongTensor] = None,
        cfg_text_packed_query_indexes: Optional[torch.LongTensor] = None,
        cfg_text_key_values_lens: Optional[torch.Tensor] = None,
        cfg_text_past_key_values: Optional[NaiveCache] = None,
        cfg_text_packed_key_value_indexes: Optional[torch.LongTensor] = None,
        # cfg_img
        cfg_img_scale: float = 1.0,
        cfg_img_packed_position_ids: Optional[torch.LongTensor] = None,
        cfg_img_packed_query_indexes: Optional[torch.LongTensor] = None,
        cfg_img_key_values_lens: Optional[torch.Tensor] = None,
        cfg_img_past_key_values: Optional[NaiveCache] = None,
        cfg_img_packed_key_value_indexes: Optional[torch.LongTensor] = None,
        cfg_type: str = "parallel",
        # cache
        model_pred_cache_dic: Optional[Dict[str, Any]] = None,
        model_pred_current: Optional[int] = None,
        model_pred_text_cache_dic: Optional[Dict[str, Any]] = None,
        model_pred_text_current: Optional[int] = None,
        model_pred_img_cache_dic: Optional[Dict[str, Any]] = None,
        model_pred_img_current: Optional[int] = None,
    ):
        packed_text_embedding = self.language_model.model.embed_tokens(packed_text_ids)
        packed_sequence = packed_text_embedding.new_zeros(
            (sum(packed_seqlens), self.hidden_size)
        )
        packed_sequence[packed_text_indexes] = packed_text_embedding

        assert timestep.unique().shape[0] == 1
        packed_pos_embed = self.latent_pos_embed(packed_vae_position_ids)
        packed_timestep_embeds = self.time_embedder(timestep)
        x_t = self.vae2llm(x_t) + packed_timestep_embeds + packed_pos_embed
        if x_t.dtype != packed_sequence.dtype:
            x_t = x_t.to(packed_sequence.dtype)
        packed_sequence[packed_vae_token_indexes] = x_t

        extra_inputs = {}
        if self.use_moe:
            extra_inputs = {
                "mode": "gen",
                "packed_vae_token_indexes": packed_vae_token_indexes,
                "packed_text_indexes": packed_text_indexes,
            }

        if self.language_model.model.enable_taylorseer:
            self.language_model.model.cache_dic = model_pred_cache_dic
            self.language_model.model.current = model_pred_current

        output = self.language_model.forward_inference(
            packed_query_sequence=packed_sequence,
            query_lens=packed_seqlens,
            packed_query_position_ids=packed_position_ids,
            packed_query_indexes=packed_indexes,
            past_key_values=past_key_values,
            key_values_lens=key_values_lens,
            packed_key_value_indexes=packed_key_value_indexes,
            update_past_key_values=False,  # !!!
            is_causal=False,
            **extra_inputs,
        )
        v_t = self.llm2vae(output.packed_query_sequence)
        v_t = v_t[packed_vae_token_indexes]
        base_v_t = v_t
        metric_payload: Dict[str, Any] = {
            "cfg_applied": bool(cfg_text_scale > 1.0),
            "cfg_text_scale_active": float(cfg_text_scale),
            "cfg_img_scale_active": float(cfg_img_scale),
            "cfg_base_norm": float(torch.norm(base_v_t).item()),
        }

        if cfg_text_scale > 1.0:
            if self.language_model.model.enable_taylorseer:
                self.language_model.model.cache_dic = model_pred_text_cache_dic
                self.language_model.model.current = model_pred_text_current
            cfg_text_output = self.language_model.forward_inference(
                packed_query_sequence=packed_sequence,
                query_lens=packed_seqlens,
                packed_query_position_ids=cfg_text_packed_position_ids,
                packed_query_indexes=cfg_text_packed_query_indexes,
                past_key_values=cfg_text_past_key_values,
                key_values_lens=cfg_text_key_values_lens,
                packed_key_value_indexes=cfg_text_packed_key_value_indexes,
                update_past_key_values=False,
                is_causal=False,
                **extra_inputs,
            )
            cfg_text_v_t = self.llm2vae(cfg_text_output.packed_query_sequence)
            cfg_text_v_t = cfg_text_v_t[packed_vae_token_indexes]
            cfg_text_residual = base_v_t - cfg_text_v_t
            metric_payload["cfg_text_residual_norm"] = float(
                torch.norm(cfg_text_residual).item()
            )
            metric_payload["cfg_text_residual_mean_abs"] = float(
                cfg_text_residual.abs().mean().item()
            )

        if cfg_img_scale > 1.0:
            if self.language_model.model.enable_taylorseer:
                self.language_model.model.cache_dic = model_pred_img_cache_dic
                self.language_model.model.current = model_pred_img_current
            cfg_img_output = self.language_model.forward_inference(
                packed_query_sequence=packed_sequence,
                query_lens=packed_seqlens,
                packed_query_position_ids=cfg_img_packed_position_ids,
                packed_query_indexes=cfg_img_packed_query_indexes,
                past_key_values=cfg_img_past_key_values,
                key_values_lens=cfg_img_key_values_lens,
                packed_key_value_indexes=cfg_img_packed_key_value_indexes,
                update_past_key_values=False,
                is_causal=False,
                **extra_inputs,
            )
            cfg_img_v_t = self.llm2vae(cfg_img_output.packed_query_sequence)
            cfg_img_v_t = cfg_img_v_t[packed_vae_token_indexes]

        if cfg_text_scale > 1.0:
            if cfg_renorm_type == "text_channel":
                v_t_text_ = cfg_text_v_t + cfg_text_scale * (
                    v_t - cfg_text_v_t
                )  # 文本引导：完全无文本引导+有引导的差值放大
                metric_payload["cfg_text_branch_norm"] = float(
                    torch.norm(v_t_text_).item()
                )
                norm_v_t = torch.norm(v_t, dim=-1, keepdim=True)
                norm_v_t_text_ = torch.norm(v_t_text_, dim=-1, keepdim=True)
                scale = (norm_v_t / (norm_v_t_text_ + 1e-8)).clamp(
                    min=cfg_renorm_min, max=1.0
                )
                v_t_text = v_t_text_ * scale
                metric_payload["cfg_text_post_renorm_norm"] = float(
                    torch.norm(v_t_text).item()
                )
                if cfg_img_scale > 1.0:
                    cfg_img_residual = v_t_text - cfg_img_v_t
                    metric_payload["cfg_img_residual_norm"] = float(
                        torch.norm(cfg_img_residual).item()
                    )
                    metric_payload["cfg_img_residual_mean_abs"] = float(
                        cfg_img_residual.abs().mean().item()
                    )
                    v_t = cfg_img_v_t + cfg_img_scale * (v_t_text - cfg_img_v_t)
                    metric_payload["cfg_combined_pre_renorm_norm"] = float(
                        torch.norm(v_t).item()
                    )
                else:
                    v_t = v_t_text
            else:
                v_t_text_ = cfg_text_v_t + cfg_text_scale * (v_t - cfg_text_v_t)
                metric_payload["cfg_text_branch_norm"] = float(
                    torch.norm(v_t_text_).item()
                )

                if cfg_img_scale > 1.0:
                    cfg_img_residual = v_t_text_ - cfg_img_v_t
                    metric_payload["cfg_img_residual_norm"] = float(
                        torch.norm(cfg_img_residual).item()
                    )
                    metric_payload["cfg_img_residual_mean_abs"] = float(
                        cfg_img_residual.abs().mean().item()
                    )
                    v_t_ = cfg_img_v_t + cfg_img_scale * (v_t_text_ - cfg_img_v_t)
                else:
                    v_t_ = v_t_text_
                metric_payload["cfg_combined_pre_renorm_norm"] = float(
                    torch.norm(v_t_).item()
                )

                # NOTE norm is computed over all dimensions, thus currently only supports batch_size = 1 with navit
                if cfg_renorm_type == "global":
                    norm_v_t = torch.norm(v_t)
                    norm_v_t_ = torch.norm(v_t_)
                elif cfg_renorm_type == "channel":
                    norm_v_t = torch.norm(v_t, dim=-1, keepdim=True)
                    norm_v_t_ = torch.norm(v_t_, dim=-1, keepdim=True)
                else:
                    raise NotImplementedError(f"{cfg_renorm_type} is not suppoprted")
                scale = (norm_v_t / (norm_v_t_ + 1e-8)).clamp(
                    min=cfg_renorm_min, max=1.0
                )
                v_t = v_t_ * scale
            scale_float = scale.detach().to(torch.float32)
            metric_payload["cfg_renorm_scale_mean"] = float(scale_float.mean().item())
            metric_payload["cfg_renorm_scale_min"] = float(scale_float.min().item())
            metric_payload["cfg_renorm_scale_max"] = float(scale_float.max().item())
        else:
            # No CFG
            metric_payload["cfg_renorm_scale_mean"] = 1.0
            metric_payload["cfg_renorm_scale_min"] = 1.0
            metric_payload["cfg_renorm_scale_max"] = 1.0

        final_delta = v_t - base_v_t
        metric_payload["cfg_final_norm"] = float(torch.norm(v_t).item())
        metric_payload["cfg_final_delta_norm"] = float(torch.norm(final_delta).item())
        metric_payload["cfg_final_delta_mean_abs"] = float(
            final_delta.abs().mean().item()
        )

        return v_t, metric_payload

    def prepare_start_tokens(self, curr_kvlens, curr_rope, new_token_ids):
        packed_start_tokens, packed_key_value_indexes = list(), list()
        packed_query_position_ids = list()

        curr = 0
        for curr_kvlen, curr_position_id in zip(curr_kvlens, curr_rope):
            packed_key_value_indexes.extend(range(curr, curr + curr_kvlen))
            packed_start_tokens.append(new_token_ids["bos_token_id"])
            packed_query_position_ids.append(curr_position_id)
            curr += curr_kvlen

        generation_input = {
            "packed_start_tokens": torch.tensor(packed_start_tokens, dtype=torch.long),
            "packed_query_position_ids": torch.tensor(
                packed_query_position_ids, dtype=torch.long
            ),
            "key_values_lens": torch.tensor(curr_kvlens, dtype=torch.int),
            "packed_key_value_indexes": torch.tensor(
                packed_key_value_indexes, dtype=torch.long
            ),
        }

        return generation_input

    @torch.no_grad
    def generate_text(  # decode
        self,
        past_key_values: NaiveCache,
        packed_key_value_indexes: torch.LongTensor,
        key_values_lens: torch.IntTensor,
        packed_start_tokens: torch.LongTensor,
        packed_query_position_ids: torch.LongTensor,
        max_length: int,
        do_sample: bool = False,
        temperature: float = 1.0,
        end_token_id: int = None,
        return_logprobs: bool = False,
        return_top2_probs: bool = False,
        return_topk_truncated_entropy: bool = False,
        return_topk_probs: bool = False,
        return_topk_ids: bool = False,
        topk_truncated_entropy_k: int = 10,
    ):
        requested_topk_k = max(1, int(topk_truncated_entropy_k))

        def _compute_topk_stats(probs: torch.Tensor):
            vocab_size = int(probs.shape[-1])
            actual_topk_k = min(requested_topk_k, vocab_size)
            topk = torch.topk(probs, k=actual_topk_k, dim=-1)
            topk_probs = topk.values.to(torch.float32)
            topk_ids = topk.indices.to(torch.long)
            truncated_entropy = -(
                topk_probs * torch.log(topk_probs.clamp_min(1e-12))
            ).sum(dim=-1)
            if actual_topk_k < requested_topk_k:
                pad = torch.full(
                    topk_probs.shape[:-1] + (requested_topk_k - actual_topk_k,),
                    float("nan"),
                    device=topk_probs.device,
                    dtype=topk_probs.dtype,
                )
                topk_probs = torch.cat([topk_probs, pad], dim=-1)
                id_pad = torch.full(
                    topk_ids.shape[:-1] + (requested_topk_k - actual_topk_k,),
                    -1,
                    device=topk_ids.device,
                    dtype=topk_ids.dtype,
                )
                topk_ids = torch.cat([topk_ids, id_pad], dim=-1)
            return topk_probs, topk_ids, truncated_entropy

        step = 0
        generated_sequence = []
        curr_tokens = packed_start_tokens
        if return_logprobs:
            generated_logprobs = []
            curr_token_logprob = torch.full(
                curr_tokens.shape,
                float("nan"),
                device=curr_tokens.device,
                dtype=torch.float32,
            )
        if return_top2_probs:
            generated_top2_probs = []
            curr_token_top2 = torch.full(
                curr_tokens.shape + (2,),
                float("nan"),
                device=curr_tokens.device,
                dtype=torch.float32,
            )
        if return_topk_truncated_entropy:
            generated_topk_truncated_entropy = []
            curr_token_topk_truncated_entropy = torch.full(
                curr_tokens.shape,
                float("nan"),
                device=curr_tokens.device,
                dtype=torch.float32,
            )
        if return_topk_probs:
            generated_topk_probs = []
            curr_token_topk_probs = torch.full(
                curr_tokens.shape + (requested_topk_k,),
                float("nan"),
                device=curr_tokens.device,
                dtype=torch.float32,
            )
        if return_topk_ids:
            generated_topk_ids = []
            curr_token_topk_ids = torch.full(
                curr_tokens.shape + (requested_topk_k,),
                -1,
                device=curr_tokens.device,
                dtype=torch.long,
            )
        # auto-regressive generation 这里的step就是生成的token数量
        while step < max_length:
            decode_step = step + 1
            decode_trace = dict(getattr(past_key_values, "metric_trace", {}) or {})
            decode_trace["decode_token_step"] = decode_step
            decode_trace["decode_max_steps"] = int(max_length)
            decode_trace["decode_is_terminal"] = bool(decode_step >= max_length)
            past_key_values.metric_trace = decode_trace
            generated_sequence.append(curr_tokens)
            if return_logprobs:
                generated_logprobs.append(curr_token_logprob)
            if return_top2_probs:
                generated_top2_probs.append(curr_token_top2)
            if return_topk_truncated_entropy:
                generated_topk_truncated_entropy.append(
                    curr_token_topk_truncated_entropy
                )
            if return_topk_probs:
                generated_topk_probs.append(curr_token_topk_probs)
            if return_topk_ids:
                generated_topk_ids.append(curr_token_topk_ids)
            packed_text_embedding = self.language_model.model.embed_tokens(curr_tokens)
            query_lens = torch.ones_like(curr_tokens)
            packed_query_indexes = torch.cumsum(key_values_lens, dim=0) + torch.arange(
                0,
                len(key_values_lens),
                device=key_values_lens.device,
                dtype=key_values_lens.dtype,
            )

            uppacked = list(
                packed_key_value_indexes.split(key_values_lens.tolist(), dim=0)
            )
            for i in range(len(uppacked)):
                uppacked[i] += i
            packed_key_value_indexes = torch.cat(uppacked, dim=0)

            extra_inputs = {}
            if self.use_moe:
                extra_inputs = {"mode": "und"}

            output = self.language_model.forward_inference(
                packed_query_sequence=packed_text_embedding,
                query_lens=query_lens,
                packed_query_position_ids=packed_query_position_ids,
                packed_query_indexes=packed_query_indexes,
                past_key_values=past_key_values,
                key_values_lens=key_values_lens,
                packed_key_value_indexes=packed_key_value_indexes,
                update_past_key_values=True,
                is_causal=True,
                **extra_inputs,
            )
            past_key_values = output.past_key_values
            packed_query_sequence = output.packed_query_sequence
            pred_logits = self.language_model.lm_head(packed_query_sequence)

            if do_sample:
                if temperature <= 0:
                    raise ValueError("temperature must be > 0 when sampling")
                scaled_logits = (pred_logits / temperature).float()
                probs = nn.functional.softmax(scaled_logits, dim=-1)
                curr_tokens = torch.multinomial(probs, num_samples=1).squeeze(1)
                if return_top2_probs:
                    curr_token_top2 = torch.topk(
                        probs, k=min(2, probs.shape[-1]), dim=-1
                    ).values.to(torch.float32)
                    if curr_token_top2.shape[-1] == 1:
                        curr_token_top2 = torch.cat(
                            [
                                curr_token_top2,
                                torch.full_like(curr_token_top2, float("nan")),
                            ],
                            dim=-1,
                        )
                if (
                    return_topk_truncated_entropy
                    or return_topk_probs
                    or return_topk_ids
                ):
                    curr_topk_probs, curr_topk_ids, curr_topk_truncated_entropy = (
                        _compute_topk_stats(probs)
                    )
                    if return_topk_truncated_entropy:
                        curr_token_topk_truncated_entropy = curr_topk_truncated_entropy
                    if return_topk_probs:
                        curr_token_topk_probs = curr_topk_probs
                    if return_topk_ids:
                        curr_token_topk_ids = curr_topk_ids
                if return_logprobs:
                    gathered = torch.gather(
                        torch.clamp(probs, min=1e-12).log(),
                        dim=-1,
                        index=curr_tokens.unsqueeze(-1),
                    ).squeeze(-1)
                    curr_token_logprob = gathered.to(torch.float32)

                    # logp = F.log_softmax(scaled_logits.float(), dim=-1)
                    # curr_token_logprob = logp.gather(-1, curr_tokens.unsqueeze(-1)).squeeze(-1)

            else:
                curr_tokens = torch.argmax(pred_logits, dim=-1)
                if return_top2_probs:
                    probs = nn.functional.softmax(pred_logits.float(), dim=-1)
                    curr_token_top2 = torch.topk(
                        probs, k=min(2, probs.shape[-1]), dim=-1
                    ).values.to(torch.float32)
                    if curr_token_top2.shape[-1] == 1:
                        curr_token_top2 = torch.cat(
                            [
                                curr_token_top2,
                                torch.full_like(curr_token_top2, float("nan")),
                            ],
                            dim=-1,
                        )
                    if (
                        return_topk_truncated_entropy
                        or return_topk_probs
                        or return_topk_ids
                    ):
                        curr_topk_probs, curr_topk_ids, curr_topk_truncated_entropy = (
                            _compute_topk_stats(probs)
                        )
                        if return_topk_truncated_entropy:
                            curr_token_topk_truncated_entropy = (
                                curr_topk_truncated_entropy
                            )
                        if return_topk_probs:
                            curr_token_topk_probs = curr_topk_probs
                        if return_topk_ids:
                            curr_token_topk_ids = curr_topk_ids
                elif (
                    return_topk_truncated_entropy
                    or return_topk_probs
                    or return_topk_ids
                ):
                    probs = nn.functional.softmax(pred_logits.float(), dim=-1)
                    curr_topk_probs, curr_topk_ids, curr_topk_truncated_entropy = (
                        _compute_topk_stats(probs)
                    )
                    if return_topk_truncated_entropy:
                        curr_token_topk_truncated_entropy = curr_topk_truncated_entropy
                    if return_topk_probs:
                        curr_token_topk_probs = curr_topk_probs
                    if return_topk_ids:
                        curr_token_topk_ids = curr_topk_ids
                if return_logprobs:
                    log_probs = nn.functional.log_softmax(pred_logits, dim=-1)
                    gathered = torch.gather(
                        log_probs,
                        dim=-1,
                        index=curr_tokens.unsqueeze(-1),
                    ).squeeze(-1)
                    curr_token_logprob = gathered.to(torch.float32)

            uppacked = list(
                packed_key_value_indexes.split(key_values_lens.tolist(), dim=0)
            )
            for i in range(len(uppacked)):
                uppacked[i] = torch.cat(
                    [
                        uppacked[i],
                        torch.tensor([uppacked[i][-1] + 1], device=uppacked[i].device),
                    ],
                    dim=0,
                )
            packed_key_value_indexes = torch.cat(uppacked, dim=0)
            key_values_lens = key_values_lens + 1
            packed_query_position_ids = packed_query_position_ids + 1
            step += 1

            # Check if we hit the end token (i.e., <|im_end|>)
            if (
                end_token_id is not None and curr_tokens[0] == end_token_id
            ):  # only support batch=1
                generated_sequence.append(curr_tokens)
                if return_logprobs:
                    generated_logprobs.append(curr_token_logprob)
                if return_top2_probs:
                    generated_top2_probs.append(curr_token_top2)
                if return_topk_truncated_entropy:
                    generated_topk_truncated_entropy.append(
                        curr_token_topk_truncated_entropy
                    )
                if return_topk_probs:
                    generated_topk_probs.append(curr_token_topk_probs)
                if return_topk_ids:
                    generated_topk_ids.append(curr_token_topk_ids)

                # Generate one more token to determine the next action
                packed_text_embedding = self.language_model.model.embed_tokens(
                    curr_tokens
                )

                uppacked = list(
                    packed_key_value_indexes.split(key_values_lens.tolist(), dim=0)
                )
                for i in range(len(uppacked)):
                    uppacked[i] += i
                packed_key_value_indexes = torch.cat(uppacked, dim=0)
                terminal_trace = dict(
                    getattr(past_key_values, "metric_trace", {}) or {}
                )
                terminal_trace["decode_is_terminal"] = True
                terminal_trace["decode_after_im_end_probe"] = True
                past_key_values.metric_trace = terminal_trace

                output = self.language_model.forward_inference(
                    packed_query_sequence=packed_text_embedding,
                    query_lens=query_lens,
                    packed_query_position_ids=packed_query_position_ids,
                    packed_query_indexes=packed_query_indexes,
                    past_key_values=past_key_values,
                    key_values_lens=key_values_lens,
                    packed_key_value_indexes=packed_key_value_indexes,
                    update_past_key_values=False,  # Don't update cache for this prediction
                    is_causal=True,
                    **extra_inputs,
                )

                pred_logits = self.language_model.lm_head(output.packed_query_sequence)
                if do_sample:
                    if temperature <= 0:
                        raise ValueError("temperature must be > 0 when sampling")
                    probs = nn.functional.softmax(pred_logits / temperature, dim=-1)
                    next_token = torch.multinomial(probs, num_samples=1).squeeze(1)
                    if return_top2_probs:
                        next_top2 = torch.topk(
                            probs, k=min(2, probs.shape[-1]), dim=-1
                        ).values.to(torch.float32)
                        if next_top2.shape[-1] == 1:
                            next_top2 = torch.cat(
                                [next_top2, torch.full_like(next_top2, float("nan"))],
                                dim=-1,
                            )
                    if (
                        return_topk_truncated_entropy
                        or return_topk_probs
                        or return_topk_ids
                    ):
                        next_topk_probs, next_topk_ids, next_topk_truncated_entropy = (
                            _compute_topk_stats(probs)
                        )
                    if return_logprobs:
                        next_logprob = (
                            torch.gather(
                                torch.clamp(probs, min=1e-12).log(),
                                dim=-1,
                                index=next_token.unsqueeze(-1),
                            )
                            .squeeze(-1)
                            .to(torch.float32)
                        )
                else:
                    next_token = torch.argmax(pred_logits, dim=-1)
                    if return_top2_probs:
                        probs = nn.functional.softmax(pred_logits.float(), dim=-1)
                        next_top2 = torch.topk(
                            probs, k=min(2, probs.shape[-1]), dim=-1
                        ).values.to(torch.float32)
                        if next_top2.shape[-1] == 1:
                            next_top2 = torch.cat(
                                [next_top2, torch.full_like(next_top2, float("nan"))],
                                dim=-1,
                            )
                        if (
                            return_topk_truncated_entropy
                            or return_topk_probs
                            or return_topk_ids
                        ):
                            (
                                next_topk_probs,
                                next_topk_ids,
                                next_topk_truncated_entropy,
                            ) = _compute_topk_stats(probs)
                    elif (
                        return_topk_truncated_entropy
                        or return_topk_probs
                        or return_topk_ids
                    ):
                        probs = nn.functional.softmax(pred_logits.float(), dim=-1)
                        next_topk_probs, next_topk_ids, next_topk_truncated_entropy = (
                            _compute_topk_stats(probs)
                        )
                    if return_logprobs:
                        next_logprob = (
                            torch.gather(
                                nn.functional.log_softmax(pred_logits, dim=-1),
                                dim=-1,
                                index=next_token.unsqueeze(-1),
                            )
                            .squeeze(-1)
                            .to(torch.float32)
                        )

                # Always include the next token after <|im_end|>
                generated_sequence.append(next_token)
                if return_logprobs:
                    generated_logprobs.append(next_logprob)
                if return_top2_probs:
                    generated_top2_probs.append(next_top2)
                if return_topk_truncated_entropy:
                    generated_topk_truncated_entropy.append(next_topk_truncated_entropy)
                if return_topk_probs:
                    generated_topk_probs.append(next_topk_probs)
                if return_topk_ids:
                    generated_topk_ids.append(next_topk_ids)

                break

        output_device = generated_sequence[0].device
        output_tokens = torch.stack(
            [i.to(output_device) for i in generated_sequence], dim=0
        )
        if (
            not return_logprobs
            and not return_top2_probs
            and not return_topk_truncated_entropy
            and not return_topk_probs
            and not return_topk_ids
        ):
            return output_tokens

        outputs = [output_tokens]
        if return_logprobs:
            logprob_device = generated_logprobs[0].device
            output_logprobs = torch.stack(
                [i.to(logprob_device) for i in generated_logprobs],
                dim=0,
            )
            outputs.append(output_logprobs)
        if return_top2_probs:
            top2_device = generated_top2_probs[0].device
            output_top2_probs = torch.stack(
                [i.to(top2_device) for i in generated_top2_probs],
                dim=0,
            )
            outputs.append(output_top2_probs)
        if return_topk_truncated_entropy:
            entropy_device = generated_topk_truncated_entropy[0].device
            output_topk_truncated_entropy = torch.stack(
                [i.to(entropy_device) for i in generated_topk_truncated_entropy],
                dim=0,
            )
            outputs.append(output_topk_truncated_entropy)
        if return_topk_probs:
            topk_device = generated_topk_probs[0].device
            output_topk_probs = torch.stack(
                [i.to(topk_device) for i in generated_topk_probs],
                dim=0,
            )
            outputs.append(output_topk_probs)
        if return_topk_ids:
            topk_ids_device = generated_topk_ids[0].device
            output_topk_ids = torch.stack(
                [i.to(topk_ids_device) for i in generated_topk_ids],
                dim=0,
            )
            outputs.append(output_topk_ids)
        return tuple(outputs)

    # for evaluation
    @torch.no_grad()
    def chat(
        self,
        tokenizer,
        new_token_ids,
        image_transform,
        images,
        prompt,
        max_length: int,
        do_sample: bool = False,
        temperature: float = 1.0,
    ):
        device = next(self.parameters()).device

        if isinstance(new_token_ids, dict):
            for k, v in new_token_ids.items():
                if torch.is_tensor(v):
                    new_token_ids[k] = v.to(device)
        elif torch.is_tensor(new_token_ids):
            new_token_ids = new_token_ids.to(device)

        # prefill
        past_key_values = NaiveCache(self.config.llm_config.num_hidden_layers)
        newlens = [0]
        new_rope = [0]

        # add images
        for image in images:
            generation_input, newlens, new_rope = self.prepare_vit_images(
                curr_kvlens=newlens,
                curr_rope=new_rope,
                images=[image],
                transforms=image_transform,
                new_token_ids=new_token_ids,
            )
            for k, v in generation_input.items():
                if torch.is_tensor(v):
                    generation_input[k] = v.to(device)
            with torch.amp.autocast("cuda", enabled=True, dtype=torch.bfloat16):
                past_key_values = self.forward_cache_update_vit(
                    past_key_values, **generation_input
                )

        # add text
        generation_input, newlens, new_rope = self.prepare_prompts(
            curr_kvlens=newlens,
            curr_rope=new_rope,
            prompts=[prompt],
            tokenizer=tokenizer,
            new_token_ids=new_token_ids,
        )
        for k, v in generation_input.items():
            if torch.is_tensor(v):
                generation_input[k] = v.to(device)
        with torch.amp.autocast("cuda", enabled=True, dtype=torch.bfloat16):
            past_key_values = self.forward_cache_update_text(
                past_key_values, **generation_input
            )

        # decode
        generation_input = self.prepare_start_tokens(newlens, new_rope, new_token_ids)
        for k, v in generation_input.items():
            if torch.is_tensor(v):
                generation_input[k] = v.to(device)
        with torch.amp.autocast("cuda", enabled=True, dtype=torch.bfloat16):
            unpacked_latent = self.generate_text(
                past_key_values=past_key_values,
                max_length=max_length,
                do_sample=do_sample,
                temperature=temperature,
                end_token_id=new_token_ids["eos_token_id"],
                **generation_input,
            )
        output = tokenizer.decode(unpacked_latent[:, 0])
        output = output.split("<|im_end|>")[0].split("<|im_start|>")[1]

        return output
