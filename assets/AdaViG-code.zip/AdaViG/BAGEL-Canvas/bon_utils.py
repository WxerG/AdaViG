from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple
import re

_TAG_PATTERN = re.compile(r"<\s*(\d+)\s*>(.*?)<\s*/\s*\1\s*>", re.DOTALL)
_BOXED_PATTERN = re.compile(r"\\boxed\{([^}]*)\}")
_BOXED_SINGLE_PATTERN = re.compile(r"\\?boxed\{([^}]*)\}")
_ENUM_PATTERN = re.compile(
    r"^(?:\(?\s*(\d+)\s*\)?|[（(]\s*(\d+)\s*[)）]|Part\s+([A-Z]))\s*[:：.\-\u3002]\s*(.+)$",
    re.IGNORECASE,
)
_FINAL_LINE_PATTERN = re.compile(
    r"(?:最终答案|Final Answer|Answer|答案)[:：]\s*(.+)$", re.IGNORECASE
)

_ANSWER_EXTRACTOR: Optional[Callable[[str], Optional[str]]] = None


@dataclass
class SegmentTextInfo:
    text: str
    raw_text: str
    token_texts: List[str]
    token_logprobs: List[float]
    token_logprob_nan_mask: List[bool]


@dataclass
class AnswerSpan:
    segment_index: int
    token_start: int
    token_end: int


def _clean_answer(text: Optional[str]) -> Optional[str]:
    if text is None:
        return None
    stripped = text.strip()
    if not stripped:
        return None
    stripped = re.sub(r"\s+", " ", stripped)
    return stripped


def _normalize_for_signature(text: Optional[str]) -> Optional[str]:
    cleaned = _clean_answer(text)
    if cleaned is None:
        return None
    normalized = cleaned.lower()
    normalized = re.sub(r"\s+", " ", normalized)
    return normalized


def _char_span_to_token_span(
    token_texts: List[str], span_start: int, span_end: int
) -> Optional[Tuple[int, int]]:
    cursor = 0
    token_start: Optional[int] = None
    token_end: Optional[int] = None
    for idx, piece in enumerate(token_texts):
        next_cursor = cursor + len(piece)
        if token_start is None and span_start < next_cursor:
            token_start = idx
        if span_end <= next_cursor:
            token_end = idx + 1
            break
        cursor = next_cursor
    if token_start is None or token_end is None:
        return None
    return token_start, token_end


def _find_matches(
    pattern: re.Pattern, segments: List[SegmentTextInfo]
) -> List[Tuple[int, re.Match]]:
    results: List[Tuple[int, re.Match]] = []
    for seg_idx, segment in enumerate(segments):
        raw_text = segment.raw_text
        if not raw_text:
            continue
        for match in pattern.finditer(raw_text):
            results.append((seg_idx, match))
    return results


def _extract_boxed_answers(
    segments: List[SegmentTextInfo],
) -> Optional[Tuple[List[Optional[str]], List[Optional[AnswerSpan]]]]:
    matches = _find_matches(_BOXED_PATTERN, segments)
    if not matches:
        matches = _find_matches(_BOXED_SINGLE_PATTERN, segments)
    if not matches:
        return None

    answers: List[Optional[str]] = []
    spans: List[Optional[AnswerSpan]] = []
    for seg_idx, match in matches:
        answer_text = _clean_answer(match.group(1))
        token_span = _char_span_to_token_span(
            segments[seg_idx].token_texts,
            match.start(1),
            match.end(1),
        )
        if token_span is None:
            spans.append(None)
        else:
            spans.append(
                AnswerSpan(
                    segment_index=seg_idx,
                    token_start=token_span[0],
                    token_end=token_span[1],
                )
            )
        answers.append(answer_text)
    return answers, spans


def set_answer_extractor(extractor: Optional[Callable[[str], Optional[str]]]) -> None:
    global _ANSWER_EXTRACTOR
    _ANSWER_EXTRACTOR = extractor


def _extract_with_custom_extractor(
    segments: List[SegmentTextInfo],
    problem: Optional[dict] = None,
) -> Optional[Tuple[List[Optional[str]], List[Optional[AnswerSpan]]]]:
    if _ANSWER_EXTRACTOR is None:
        return None
    text_segments = [segment.raw_text for segment in segments if segment.raw_text]
    if not text_segments:
        return None
    try:
        candidate = _ANSWER_EXTRACTOR(text_segments[-1], problem=problem)
    except TypeError:
        candidate = _ANSWER_EXTRACTOR(text_segments[-1])
    if not candidate:
        try:
            candidate = _ANSWER_EXTRACTOR("\n".join(text_segments), problem=problem)
        except TypeError:
            candidate = _ANSWER_EXTRACTOR("\n".join(text_segments))
    if not candidate:
        return None
    return [candidate], [None]


def extract_answers_and_signature(
    segments: List[SegmentTextInfo],
    problem: Optional[dict] = None,
) -> Tuple[List[Optional[str]], Tuple[Optional[str], ...], List[Optional[AnswerSpan]]]:
    """Parse answers from text segments and track their token spans."""
    custom_result = _extract_with_custom_extractor(segments, problem=problem)
    boxed_result = _extract_boxed_answers(segments)

    answers: Optional[List[Optional[str]]] = None
    spans: Optional[List[Optional[AnswerSpan]]] = None

    if custom_result:
        answers, spans = custom_result
        if boxed_result:
            _, boxed_spans = boxed_result
            if boxed_spans:
                spans = boxed_spans
    elif boxed_result:
        answers, spans = boxed_result
    else:
        answers = [None]
        spans = [None]

    signature = tuple(_normalize_for_signature(ans) for ans in answers)
    return answers, signature, spans
