# AdaViG

**Model Guides You How to Draw: Adaptive Visual Gating for Unified Multimodal Reasoning**

AdaViG is a training-free method that decides whether to continue a visual reasoning step. At an early diffusion step, it measures **Generation Intent** (attention to the preceding text) and **Visual Fidelity** (attention to the input image). When both signals are weak, it stops image generation and resumes text reasoning.

This repository contains inference, attention instrumentation, threshold calibration, and benchmark evaluation for the BAGEL-Canvas implementation. It includes the inference dependencies from [MathCanvas](https://github.com/shiwk24/MathCanvas); no separate MathCanvas checkout or patch installer is required.

## Setup

Use Linux with an NVIDIA GPU, a CUDA-compatible PyTorch installation, and Python 3.10. Model weights and benchmark images are downloaded separately. GPU memory requirements depend on the checkpoint and context length; this release has not established a minimum VRAM requirement.

```bash
conda create -n adavig python=3.10 -y
conda activate adavig
pip install -r requirements.txt
pip install flash-attn==2.8.2 --no-build-isolation
```

FlashAttention must match your CUDA and PyTorch build. The attention instrumentation also imports its reference implementation at `flash_attn.flash_attn_triton_amd.fwd_ref`; retain that module when building FlashAttention.

Download the [BAGEL-Canvas checkpoint](https://huggingface.co/shiwk24/BAGEL-Canvas) with its tokenizer, model configuration, image encoder, and VAE files. Preserve the checkpoint's original directory layout.

## Inference

Run commands from the repository root. `INPUT_PATH` is a JSONL file; image paths in that file are resolved relative to `IMAGE_ROOT`. See [data preparation](docs/data.md).

```bash
export CHECKPOINT_DIR=/path/to/BAGEL-Canvas
export INPUT_PATH=/path/to/mathvision/testmini.jsonl
export IMAGE_ROOT=/path/to/mathvision
export CUDA_VISIBLE_DEVICES=0

bash scripts/infer.sh baseline mathvision
bash scripts/infer.sh text-only mathvision
bash scripts/infer.sh gated mathvision
```

The three modes run the original visual reasoning branch, its no-generated-image counterfactual, and AdaViG respectively. Results are saved under `results/<dataset>/<dataset>_<mode>/`. Use a new `RUN_NAME` for each independent run to avoid mixing existing output and appended gate logs.

The same entry point accepts `mathvista`, `mathverse`, `olympiad`, `wemath`, and `dynamath` when their inputs have been prepared in the unified format. This release includes dedicated evaluators for MathVision, MathVista GPS, WeMath, and DynaMath.

| Setting | Default |
| --- | --- |
| Decision step | 5 |
| Total diffusion steps | 50 |
| Intent threshold (`ADAVIG_PRE_R_ALL_THR`) | 0.60 |
| Fidelity threshold (`ADAVIG_PRE_ORIG_VIT_THR`) | 0.01 |
| Baseline / text-only temperature | 0.7 |
| Gated temperature | 0.3 |
| Seed / best-of-N | 42 / 1 |

These temperatures match the supplied experiment scripts. To isolate the gate from sampling-temperature effects, set the same `TEXT_TEMPERATURE` for all compared modes. `OUTPUT_DIR`, `RUN_NAME`, and `MASTER_PORT` can also be overridden through environment variables.

The runtime continues generation when Intent **exceeds** 0.60 **or** Fidelity **exceeds** 0.01. It aborts otherwise, including exact equality. See [implementation and reproduction notes](docs/reproduction.md) for aggregation details and the distinction from the paper's strict-inequality notation.

## Evaluation

```bash
cd BAGEL-Canvas
python evaluation/eval_mathvision.py --result_dir ../results/mathvision/mathvision_baseline
python evaluation/eval_mathvista_gps.py --result_dir /path/to/mathvista/run --gt_path /path/to/testmini_gps.jsonl
python evaluation/eval_wemath.py --result_dir /path/to/wemath/run --gt_path /path/to/testmini.jsonl
python evaluation/eval_dynamath.py --result_dir /path/to/dynamath/run --gt_path /path/to/test.jsonl
```

The MathVision evaluator uses explicit answer extraction and `math-verify`. It replaces a private evaluation dependency absent from the supplied code and upstream MathCanvas. It is a rule-based evaluator, and equivalence to the paper's original scoring has not been established. WeMath reports its benchmark-specific grouped metrics; DynaMath reports its variant-level and grouped results.

## Threshold calibration

The tools in `calibration/` align baseline and text-only outcomes, extract early attention features, and search thresholds. The full procedure and logging flags are in [calibration instructions](docs/calibration.md).

Threshold-search scores are counterfactual estimates obtained by selecting between completed traces. Validate selected thresholds with a fresh online gated run before reporting accuracy or measured latency.

## Code layout

```text
BAGEL-Canvas/
  online_gate.py       Early diffusion decision and gate logs
  inferencer.py        Text/image context management
  runtime_metrics.py   Optional profiling and attention dumps
  answer_utils.py      Explicit final-answer extraction
  search/              Visual and text-only reasoning loops
  modeling/            BAGEL backbone and attention instrumentation
  data/                Inference transforms and token utilities
  data_handlers/       Unified benchmark input/output
  evaluation/          Benchmark evaluators
calibration/           Counterfactual alignment and threshold search
scripts/infer.sh       Shared inference launcher
tests/                CPU tests for gate behavior and answer extraction
```

## Validation and release scope

Run the CPU checks with:

```bash
python -m unittest discover -s tests -v
python -m compileall -q BAGEL-Canvas calibration
bash -n scripts/infer.sh
```

The release was checked for syntax and gate behavior on CPU. Full checkpoint loading, CUDA inference, and reproduction of the paper's tables require a GPU environment and the original benchmark assets; they have not been verified in this workspace. No checkpoint, benchmark data, or recorded experimental result is bundled.

## Acknowledgments and license

Built on [MathCanvas](https://github.com/shiwk24/MathCanvas) and [BAGEL](https://github.com/ByteDance-Seed/Bagel). Some benchmark scoring functions are adapted from [lmms-eval](https://github.com/EvolvingLMMs-Lab/lmms-eval). See [NOTICE](NOTICE) for source provenance and [LICENSE](LICENSE) for Apache-2.0 terms. Model weights and datasets retain their respective licenses.
