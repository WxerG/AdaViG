#!/usr/bin/env python3
import argparse
import csv
import json
import math
import os
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional


def load_eval_correctness(path: str) -> Dict[str, bool]:
    data = json.load(open(path))
    out: Dict[str, bool] = {}
    for row in data["details"]:
        out[str(row["id"])] = bool(row["correctness"])
    return out


def quantile(values: List[float], q: float) -> float:
    if not values:
        return float("nan")
    xs = sorted(values)
    if len(xs) == 1:
        return xs[0]
    pos = q * (len(xs) - 1)
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return xs[lo]
    frac = pos - lo
    return xs[lo] * (1 - frac) + xs[hi] * frac


@dataclass
class SampleMetric:
    sample_id: str
    uncertainty: Optional[float] = None
    r_all: Optional[float] = None
    orig_vit: Optional[float] = None
    choose_off: Optional[bool] = None


def load_gate_metrics(path: str) -> Dict[str, SampleMetric]:
    out: Dict[str, SampleMetric] = {}
    for line in open(path):
        row = json.loads(line)
        sid = row.get("sample_id")
        if sid is None:
            continue
        sid = str(sid)
        item = out.setdefault(sid, SampleMetric(sample_id=sid))
        kind = row["kind"]
        if kind == "decode_uncertainty":
            item.uncertainty = row["uncertainty"]
        elif kind == "pre_decision":
            item.r_all = row.get("r_all__L27__s5")
            item.orig_vit = row.get("orig_vit__L0_14_27__s5")
            item.choose_off = row.get("choose_off")
    return out


def candidate_thresholds(
    values: Iterable[float], extra: Optional[List[float]] = None
) -> List[float]:
    vals = sorted(set(float(v) for v in values if v is not None))
    if not vals:
        return []
    out = set(extra or [])
    for q in (
        0.05,
        0.1,
        0.15,
        0.2,
        0.25,
        0.3,
        0.35,
        0.4,
        0.45,
        0.5,
        0.55,
        0.6,
        0.65,
        0.7,
        0.75,
        0.8,
        0.85,
        0.9,
        0.95,
    ):
        out.add(quantile(vals, q))
    out.update(vals)
    return sorted(out)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gate_metrics", required=True)
    parser.add_argument("--baseline_eval", required=True)
    parser.add_argument("--wo_eval", required=True)
    parser.add_argument("--output_dir", required=True)
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    metrics = load_gate_metrics(args.gate_metrics)
    baseline_correct = load_eval_correctness(args.baseline_eval)
    wo_correct = load_eval_correctness(args.wo_eval)

    sample_ids = sorted(set(baseline_correct) & set(wo_correct))
    gate_applicable = sorted(
        sid
        for sid in sample_ids
        if sid in metrics
        and metrics[sid].r_all is not None
        and metrics[sid].orig_vit is not None
    )
    uncertainty_values = [
        metrics[sid].uncertainty
        for sid in gate_applicable
        if metrics[sid].uncertainty is not None
    ]
    q_values = {
        f"q{int(q * 100)}": quantile(uncertainty_values, q)
        for q in (0.8, 0.85, 0.9, 0.95)
    }

    r_thresholds = candidate_thresholds(
        [metrics[sid].r_all for sid in gate_applicable], extra=[0.6014654278372139]
    )
    vit_thresholds = candidate_thresholds(
        [metrics[sid].orig_vit for sid in gate_applicable], extra=[0.01075651803985232]
    )

    rows = []
    for q_name, q_thr in q_values.items():
        for r_thr in r_thresholds:
            for vit_thr in vit_thresholds:
                correct = 0
                chosen_off = 0
                for sid in sample_ids:
                    use_off = True
                    if sid in gate_applicable:
                        m = metrics[sid]
                        choose = ((m.r_all or -1e9) > r_thr) or (
                            (m.orig_vit or -1e9) > vit_thr
                        )
                        if m.uncertainty is not None:
                            choose = choose and (m.uncertainty <= q_thr)
                        use_off = choose
                    if use_off:
                        chosen_off += 1
                        correct += int(baseline_correct[sid])
                    else:
                        correct += int(wo_correct[sid])
                acc = correct / len(sample_ids)
                rows.append(
                    {
                        "uncertainty_quantile": q_name,
                        "uncertainty_threshold": q_thr,
                        "r_all_threshold": r_thr,
                        "orig_vit_threshold": vit_thr,
                        "accuracy": acc,
                        "correct": correct,
                        "total": len(sample_ids),
                        "chosen_off": chosen_off,
                        "chosen_wo": len(sample_ids) - chosen_off,
                    }
                )

    rows.sort(key=lambda x: (-x["accuracy"], x["chosen_off"]))

    csv_path = os.path.join(args.output_dir, "pre_gate_search_results.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=list(rows[0].keys())
            if rows
            else [
                "uncertainty_quantile",
                "uncertainty_threshold",
                "r_all_threshold",
                "orig_vit_threshold",
                "accuracy",
                "correct",
                "total",
                "chosen_off",
                "chosen_wo",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)

    topk = rows[:20]
    summary = {
        "gate_metrics": args.gate_metrics,
        "baseline_eval": args.baseline_eval,
        "wo_eval": args.wo_eval,
        "n_samples": len(sample_ids),
        "n_gate_applicable_seen": len(gate_applicable),
        "baseline_accuracy": sum(int(baseline_correct[sid]) for sid in sample_ids)
        / len(sample_ids),
        "wo_accuracy": sum(int(wo_correct[sid]) for sid in sample_ids)
        / len(sample_ids),
        "top_results": topk,
    }
    json.dump(
        summary, open(os.path.join(args.output_dir, "summary.json"), "w"), indent=2
    )

    md_path = os.path.join(args.output_dir, "report.md")
    with open(md_path, "w") as f:
        f.write("# Online Pre-Gate Retuning\n\n")
        f.write(f"- samples: `{len(sample_ids)}`\n")
        f.write(f"- gate-applicable seen so far: `{len(gate_applicable)}`\n")
        f.write(f"- baseline acc: `{summary['baseline_accuracy']:.4f}`\n")
        f.write(f"- wo acc: `{summary['wo_accuracy']:.4f}`\n\n")
        f.write("## Top Results\n\n")
        for row in topk[:10]:
            f.write(
                f"- acc=`{row['accuracy']:.4f}` "
                f"q=`{row['uncertainty_quantile']}` "
                f"u<={row['uncertainty_threshold']:.6f} "
                f"r_all>{row['r_all_threshold']:.6f} "
                f"orig_vit>{row['orig_vit_threshold']:.6f} "
                f"off=`{row['chosen_off']}` wo=`{row['chosen_wo']}`\n"
            )


if __name__ == "__main__":
    main()
