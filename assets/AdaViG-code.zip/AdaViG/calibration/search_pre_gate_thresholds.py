"""Search the two thresholds used by the deployed AdaViG pre-gate."""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

INTENT = "r_all__L27__s5"
FIDELITY = "orig_vit__L0_14_27__s5"


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input",
        type=Path,
        default=root / "analysis/adavig_gate_dataset/aligned_dataset.csv",
    )
    parser.add_argument(
        "--output_dir", type=Path, default=root / "analysis/adavig_pre_gate_search"
    )
    args = parser.parse_args()
    df = pd.read_csv(args.input)
    if df.empty:
        raise ValueError("Calibration dataset is empty")
    required = [
        INTENT,
        FIDELITY,
        "off_correct",
        "wo_correct",
        "off_cost_ms",
        "wo_cost_ms",
        "gate_applicable",
    ]
    if df[required].isna().any().any():
        raise ValueError(
            "Calibration data has missing features or outcomes; check trace alignment"
        )
    app = df["gate_applicable"].astype(str).str.lower().isin(["true", "1"]).to_numpy()
    rows = []
    quantiles = np.linspace(0, 1, 41)
    for intent_thr in np.unique(np.append(np.quantile(df[INTENT], quantiles), 0.6)):
        for fidelity_thr in np.unique(
            np.append(np.quantile(df[FIDELITY], quantiles), 0.01)
        ):
            keep = (
                ~app
                | (df[INTENT].to_numpy() > intent_thr)
                | (df[FIDELITY].to_numpy() > fidelity_thr)
            )
            correct = np.where(keep, df["off_correct"], df["wo_correct"])
            cost = np.where(keep, df["off_cost_ms"], df["wo_cost_ms"])
            rows.append(
                {
                    "intent_threshold": float(intent_thr),
                    "fidelity_threshold": float(fidelity_thr),
                    "accuracy": float(correct.mean()),
                    "counterfactual_cost_ms": float(cost.mean()),
                    "abort_count": int((~keep).sum()),
                }
            )
    results = pd.DataFrame(rows).sort_values(
        ["accuracy", "counterfactual_cost_ms"], ascending=[False, True]
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    results.to_csv(args.output_dir / "results.csv", index=False)
    summary = {
        "samples": len(df),
        "configurations": len(results),
        "best": results.iloc[0].to_dict(),
        "note": "Counterfactual estimate; validate with an online gated run.",
    }
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
