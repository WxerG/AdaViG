# Implementation and reproduction notes

## Gate

At diffusion step 5, the gate requests attention measurements at layers 0, 14, and 27 in the conditional generation branch. Classifier-free guidance branches are excluded.

- Generation Intent: layer-27 attention mass to all preceding text, divided by that mass plus layer-27 attention to the original image's ViT and VAE tokens. The denominator includes `1e-9` for numerical stability.
- Visual Fidelity: the mean positive input-image ViT attention mass at layers 0, 14, and 27. Zero masses are omitted, matching the supplied online implementation.
- Continue if either signal is strictly greater than its threshold; otherwise abort. The paper writes the abort condition with strict `<`; at exact equality the supplied runtime instead aborts. This release preserves runtime behavior.
- After abort, the partial image is discarded and further generated-image steps are disabled for that trial, matching the original inference loop.

The offline feature extractor originally averaged observed layers including zero masses. The final online gate averages positive masses only. This release aligns the final calibration feature with that online convention. Other exploratory features retain their existing definitions.

## Sampling and measurement

The original runners used text temperature 0.7 for baseline and 0.3 for AdaViG, 50 diffusion steps, best-of-N 1, seed 42, and at most 10 reasoning iterations. The shared launcher retains these values. Set `TEXT_TEMPERATURE` explicitly for a matched-temperature comparison.

Gate decisions append to `gate_metrics.jsonl` in the gated result directory. Use distinct run names for repeated experiments. Profiling and attention dumps are opt-in because they add overhead; measure latency with diagnostic dumps disabled. The runtime currently recomputes reference attention at selected layers for the gate, so this implementation has measurement overhead even though the paper describes attention reduction as negligible.

Threshold search chooses between full visual and text-only counterfactual traces. Its cost estimate is not an online latency measurement and does not include the exact partial diffusion and continuation cost. Verify the selected rule by running the real gate.

## Changes made for the public release

- Included the upstream inference dependencies from MathCanvas commit `9b48cc81ab1f63d418a954e4502c3c6274068a7b`.
- Kept the supplied AdaViG model instrumentation and inference overrides.
- Removed the experimental post-image gate, its uncertainty criterion, and unnecessary KV-cache/RNG snapshots.
- Replaced the missing private answer-extraction import with an explicit answer-tag/boxed-answer parser. This can affect saved extracted answers; original scoring parity needs validation.
- Added a rule-based MathVision evaluator for calibration. No claim of original judge parity is made.
- Replaced cluster-specific runners with one portable single-GPU launcher.
- Excluded internal meeting notes, historical recommendations, obsolete converters, publishing helpers, training code, weights, datasets, and generated output.

## Verification limits

CPU tests exercise gate decisions, attention selection, cleanup, answer extraction, and randomized decision parity with the supplied final pre-gate implementation. Syntax checks cover Python sources and the shell launcher. The workspace has no configured CUDA model environment or benchmark assets, so end-to-end inference and paper metrics remain unverified.

The current manuscript includes author metadata, but no confirmed public paper URL or final publication entry. Paper links and bibliographic details will be updated from the final accepted manuscript.
