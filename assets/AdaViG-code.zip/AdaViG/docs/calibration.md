# Calibrate the early diffusion gate

Run these commands from the repository root after setting the checkpoint and data variables shown in the README. Use the same MathVision development split and sample IDs for both branches.

```bash
export BAGEL_METRIC_DUMP=1
export BAGEL_METRIC_JSONL_ALL=1
export BAGEL_METRIC_SAVE_TENSORS=0
export BAGEL_METRIC_DUMP_DIR="$PWD/analysis/runtime_metrics"
export BAGEL_METRIC_EXACT_ATTN=1
export BAGEL_METRIC_SEGMENT_MASS=1
export BAGEL_METRIC_SAVE_IMAGEGEN_INTERNAL_STEPS=1
export BAGEL_METRIC_IMAGEGEN_SAMPLE_STEPS=1,3,5,7,9
bash scripts/infer.sh baseline mathvision
```

The runner configures the metric run group from the output directory name and the run ID from the dataset/run description. With the README defaults, metrics are written under `analysis/runtime_metrics/results/mathvision/mathvision_baseline/`.

Run the text-only counterfactual, then evaluate both outputs:

```bash
BAGEL_METRIC_DUMP=0 bash scripts/infer.sh text-only mathvision
python BAGEL-Canvas/evaluation/eval_mathvision.py --result_dir results/mathvision/mathvision_baseline
python BAGEL-Canvas/evaluation/eval_mathvision.py --result_dir results/mathvision/mathvision_text-only

export ADAVIG_OFF_RESULTS_DIR="$PWD/results/mathvision/mathvision_baseline"
export ADAVIG_WO_RESULTS_DIR="$PWD/results/mathvision/mathvision_text-only"
export ADAVIG_OFF_METRICS_DIR="$PWD/analysis/runtime_metrics/results/mathvision/mathvision_baseline"
python calibration/build_gate_dataset.py
python calibration/search_pre_gate_thresholds.py
```

If you changed `OUTPUT_DIR` or `RUN_NAME`, update the three paths accordingly. Check the actual metric directory before alignment.

`analysis/adavig_gate_dataset/aligned_dataset.csv` contains aligned correctness, cost estimates, and early attention features. Labels are `helpful` (visual branch correct, text-only wrong), `harmful` (the reverse), `neutral_keep` (both correct), and `neutral_skip` (both wrong).

The threshold search varies only the two signals used by the deployed gate at step 5. It writes `results.csv` and `summary.json` under `analysis/adavig_pre_gate_search/`, ranked by estimated accuracy and then counterfactual cost. It does not fit a model or use gradients. Calibration on the same split used for reporting would bias the reported performance; fix thresholds on a development split before evaluation.

Validate the chosen thresholds online with diagnostic logging disabled:

```bash
export BAGEL_METRIC_DUMP=0
export BAGEL_METRIC_EXACT_ATTN=0
export BAGEL_METRIC_SEGMENT_MASS=0
export ADAVIG_PRE_R_ALL_THR=0.60
export ADAVIG_PRE_ORIG_VIT_THR=0.01
RUN_NAME=mathvision_gated_validation bash scripts/infer.sh gated mathvision
```

The two threshold values above are the supplied runtime defaults. Replace them with your selected values when calibrating a different setup.

`retune_pre_gate_thresholds.py --help` provides an optional sweep over a completed gate log and baseline/text-only evaluation summaries. Like offline search, this estimates counterfactual outcomes and does not replace an online evaluation.
