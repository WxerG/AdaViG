# Benchmark inputs

The `uni` handler reads one JSON object per line. Images are not included in this repository. Obtain each benchmark from its official release and retain the metadata required by its evaluator.

```json
{"id": "example_0", "question": "What is the marked angle?", "options": ["30", "45", "60", "90"], "answer": "B", "image": "images/example_0.png"}
```

This is a format illustration, not a benchmark sample. `image` can be a relative path or a list of paths. Set `IMAGE_ROOT` to their parent directory. Preserve `id`, `question`, `answer`, and `options` (a JSON list); numerical free-form questions use an empty options list. Review benchmark-specific prompting in `BAGEL-Canvas/data_handlers/uni_handler.py`.

Sources:

- MathVision: https://github.com/mathllm/MATH-V
- MathVista: https://huggingface.co/datasets/AI4Math/MathVista
- MathCanvas-Bench: https://huggingface.co/datasets/shiwk24/MathCanvas-Bench
- WeMath: https://github.com/We-Math/We-Math
- DynaMath: https://github.com/DynaMath/DynaMath

The specialized WeMath and DynaMath evaluators require the original grouping/variant fields. Do not replace their official records with only the minimal example above. MathVista GPS must be filtered to the geometry problem solving subset before inference and evaluation. Compare identical sample IDs and splits for each mode.

The release does not contain benchmark conversion scripts with server-specific paths. Conversion from each official release should preserve the exact split, option ordering, grouping fields, and image associations used in the experiment.
